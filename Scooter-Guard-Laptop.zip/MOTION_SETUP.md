# Scooter motion and collision prediction

The live app tracks people and vehicles, fits their motion over a rolling 1.2-second window, and projects rectangular footprints every 0.1 seconds over a default six-second horizon. The first predicted overlap gives the overlap time. The smallest signed footprint separation gives the minimum gap. Negative gaps mean projected overlap. The threat score combines overlap time with a lower score for close passes, with 0.3-second persistence before alerts.

The map shows the scooter in green, its predicted path in dashed green, and target paths in blue or red. Coordinates are in the current rear-camera frame, with image-right as positive X and behind the scooter as positive Z. Targets and scooter paths use a common local reference frame. Forward scooter travel is negative Z.

## Inputs and fallback behavior

| Available data | Prediction behavior |
| --- | --- |
| Camera only | Constant relative-velocity prediction, assuming negligible camera rotation during the fit |
| Camera and calibrated yaw | Corrects historical observations for camera yaw, with a relative-motion prediction when wheel speed is unknown |
| Camera and wheel speed | Integrates scooter translation and predicts a straight scooter path while yaw is unknown |
| Camera, wheel speed, and calibrated yaw | Integrates local scooter pose and predicts its constant-speed, constant-turn-rate path against target motion |

The dashboard names the active mode and displays unavailable inputs as a dash. Wheel speed expires after one second without a measurement, and yaw expires after 0.5 seconds. Reference frames and track histories reset when available motion sources change or camera timestamps have a gap. Invalid, inconsistent depth fits suppress predictions. A camera reconnection clears the fitted tracks and OAK gyro calibration.

## Built-in OAK IMU

The app queries the connected OAK for its IMU before creating an optional gyro stream. If present, it reads raw XYZ angular rates at 100 Hz. If absent, it continues with the available motion sources.

This connected unit reported **BMI270**. Live stationary calibration and the dashboard's **yaw compensated** mode were verified. The initial Y+ mapping has not been validated against an actual scooter mount.

Mount the camera rigidly facing backward and level. Set the gyro axis and sign using the dropdown beside the calibration button. Y+ is the initial configuration and must be checked for your actual board and mount. The selected axis must be the vertical yaw axis. In the app's X/Z convention, a positive yaw rotates camera +X toward +Z. Rotate the mount by a known small angle and confirm the direction before moving-scooter evaluation.

With the mounted camera still, press **Calibrate yaw (hold still)**. Calibration collects two seconds of data and rejects excessive angular speed or variability. Accepted bias is subtracted from subsequent gyro measurements. The dashboard reports calibration and sensor status.

This implementation compensates planar yaw. Scooter leaning, pitch, roll, camera flex, and accelerometer-based tilt compensation remain outside the model. An IMU alone does not provide sustained accurate wheel speed, so accelerometer integration is not used as a substitute.

## Wheel speed with an ESP32

The included `firmware/ScooterTelemetry/ScooterTelemetry.ino` targets a classic ESP32 and needs no Arduino libraries beyond its board core. It has not been compiled or flashed in this session because no ESP32 or Arduino CLI is attached.

1. Mount a magnet on the wheel and a Hall sensor on a stationary part beside it.
2. Use a 3.3 V-compatible signal or open-collector Hall output. Connect signal to GPIO27 and share ground. Supply the sensor according to its own datasheet. Change the pin for a different ESP32 variant.
3. Measure the wheel's travel over one revolution. Set `WHEEL_CIRCUMFERENCE_M` in meters and `PULSES_PER_REV` in the sketch. The included 0.68 m value is an example, requiring replacement with your measurement.
4. Flash the sketch using Arduino IDE with the matching ESP32 board selected.
5. Connect the board to the laptop with a USB data cable and identify its COM port.
6. Start the app using the command below, substituting that port.

```powershell
.venv\Scripts\python.exe desktop.py --mode oak --autostart --usb2 --motion-port COM7
```

Rotate the wheel to generate at least two pulses before expecting a speed measurement. The firmware outputs `null` until that happens, then estimates speed from pulse interval. A timeout reports zero after the wheel stops. A disconnected Hall sensor after valid pulses can look like a stopped wheel, so compare reported speed against a measured roll test.

The included single-Hall sketch assumes forward travel. Measuring reverse direction requires a directional encoder or another direction source.

## Telemetry protocol

The serial reader expects UTF-8 newline-delimited JSON at 115200 baud. Fresh arrival times are used. Valid fields can be sent separately or together. Speed is signed meters per second, positive for forward travel. Yaw is radians per second in the rear-camera convention above. External yaw must already be bias-corrected and mount-aligned. External yaw takes precedence over the OAK gyro while fresh.

```json
{"speed_mps":3.2}
{"speed_mps":3.2,"yaw_rate_rps":0.12}
```

For integration with another program, use `--motion-file C:\path\live-motion.jsonl`. The reader watches newly appended complete lines. Existing file contents are skipped at startup, and repeated EOF reads do not refresh old measurements. This interface is intended for a live producer. Values read from recordings must be presented as simulation data by the producer and app mode.

## Optional handlebar vibration

GPIO26 in the ESP32 sketch provides an optional vibration-driver control signal. Use a suitable transistor or MOSFET driver, a flyback diode for an inductive motor, the motor's rated supply, and a shared ground. The GPIO supplies only a control signal.

Add `--haptic-output` to the serial command after attaching the driver. Python sends `R`, `F`, `B`, or `0` followed by a newline on the same motion serial connection. Rear warnings pulse twice, front warnings use a longer pulse, and simultaneous warnings hold the output active. The board turns the output off if commands stop for one second. Stale camera measurements clear rear warnings, and stale front readings clear front warnings. Haptic output is disabled by default.

The desktop also offers **Warning sound**, which uses the system alert sound while a persistent warning is active. Front LiDAR support remains optional and independent of wheel telemetry.

## Dimensions and stopping distance

Defaults are a 0.6 m wide, 1.2 m long scooter, a 0.3 m margin on every scooter edge, a six-second horizon, a one-second rider reaction time, and 2.5 m/s² deceleration. Set them for your rig with these options.

```powershell
.venv\Scripts\python.exe desktop.py --mode oak --autostart --usb2 --motion-port COM7 --scooter-width 0.6 --scooter-length 1.2 --safety-margin 0.3 --horizon 6 --reaction-time 1 --deceleration 2.5
```

The stopping estimate is `speed × reaction time + speed² / (2 × deceleration)`. It is displayed only with a current speed measurement and is separate from rear collision scoring. These reaction and deceleration settings are assumptions, not measured scooter braking performance.

Target dimensions use conservative class defaults and observed image width. Their nominal centers are offset away from the visible depth surface by half a class-dependent length. Target orientation is approximated as aligned with the current camera, with constant world velocity where scooter speed is available. Individual vehicle heading, steering, acceleration, precise 3D shape, road slope, and occluded road users are not recovered. Footprint overlap and scores remain prototype estimates requiring controlled validation.

## Validation

Run `python -m pytest test_risk.py test_tracking.py test_prediction.py -q`. Tests cover footprint overlap, safe passes, lateral crossings, scooter turns, camera rotation, equal scooter/vehicle speed, sensor expiry, invalid telemetry, stationary and moving gyro calibration, and unstable depth.

Demo mode cycles through a rear approach, a pass with lateral clearance, and a crossing pedestrian. Its camera images, tracks, and motion are explicitly synthetic.
