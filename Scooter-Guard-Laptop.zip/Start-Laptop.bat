@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe -c "import numpy, PIL, fastapi, tkinter, depthai, ultralytics, scipy" >nul 2>&1
if not errorlevel 1 goto virtualpython
python -c "import numpy, PIL, fastapi, tkinter" >nul 2>&1
if not errorlevel 1 goto systempython
.venv\Scripts\python.exe -c "import numpy, PIL, fastapi, tkinter" >nul 2>&1
if errorlevel 1 powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
if errorlevel 1 goto failed
.venv\Scripts\python.exe desktop.py %*
pause
exit /b
:virtualpython
.venv\Scripts\python.exe desktop.py %*
pause
exit /b
:systempython
python desktop.py %*
pause
exit /b
:failed
echo Setup failed. Check internet access and try again.
pause
