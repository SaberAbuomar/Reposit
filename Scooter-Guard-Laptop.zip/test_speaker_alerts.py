from io import StringIO
import json
from speaker_alerts import SpokenWarnings, warning_phrase

class Pipe(StringIO):
    def close(self): pass
class Process:
    def __init__(self): self.stdin=Pipe(); self.terminated=False
    def poll(self): return 0 if self.terminated else None
    def terminate(self): self.terminated=True
    def commands(self): return [json.loads(v) for v in self.stdin.getvalue().splitlines()]

def test_names_only_active_observed_warnings():
    assert warning_phrase([{'label':'car','alert':True}])=='Warning. car approaching.'
    assert warning_phrase([{'label':'person','alert':True},{'label':'car','alert':True}])=='Warning. car and person approaching.'
    assert warning_phrase([{'label':'person','alert':False}]) is None
    assert warning_phrase([{'label':'car','alert':True,'coasting':True}]) is None
    assert warning_phrase([{'label':'car','alert':False,'possible_turn_conflict':True}]) is None

def test_stale_error_or_empty_warnings_cancel_phrase():
    active=[{'label':'car','alert':True}]
    assert warning_phrase(active,stale=True) is None
    assert warning_phrase(active,error=True) is None
    assert warning_phrase([],front={'alert':True})=='Warning. obstacle ahead.'
    assert warning_phrase([]) is None

def test_speech_repeats_only_while_warning_active_and_cancels_once():
    clock=[0.]
    process=Process()
    speaker=SpokenWarnings(clock=lambda:clock[0],factory=lambda:process)
    speaker.update('Warning. car approaching.')
    clock[0]=1
    speaker.update('Warning. car approaching.')
    assert len(process.commands())==1
    clock[0]=5
    speaker.update('Warning. car approaching.')
    assert len(process.commands())==2
    speaker.update(None)
    assert process.commands()[-1]['action']=='cancel'
    clock[0]=30
    speaker.update(None)
    assert len(process.commands())==3

def test_disabled_switch_and_changed_class_interrupt_previous_speech():
    process=Process()
    speaker=SpokenWarnings(factory=lambda:process)
    speaker.update('Warning. car approaching.')
    speaker.update('Warning. person approaching.')
    assert process.commands()[-1]['text']=='Warning. person approaching.'
    speaker.update('Warning. person approaching.',enabled=False)
    assert process.commands()[-1]['action']=='cancel'
    speaker.close()
    assert process.terminated
    count=len(process.commands())
    speaker.update('Warning. car approaching.')
    assert len(process.commands())==count

def test_no_warning_never_starts_audio_process():
    def no_launch(): raise AssertionError('Should not launch')
    speaker=SpokenWarnings(factory=no_launch)
    speaker.update(None)
    speaker.close()

def test_worker_failure_does_not_crash_dashboard():
    def fail(): raise OSError('No audio device')
    speaker=SpokenWarnings(factory=fail)
    speaker.update('Warning. car approaching.')
    assert speaker.error=='Speaker output unavailable'
    speaker.update(None)
