"""Short-horizon, constant relative velocity threat estimation."""
from collections import deque
import numpy as np
from motion import rotation
from prediction import predict_collision


class MotionTracker:
    def __init__(self, config=None):
        self.history = {}
        self.alert_since = {}
        self.config = config or {}
        self.generation = None

    def update(self, track_id, now, x, z, width=1.8, label='car', ego=None, confidence=1.):
        ego = ego or dict(yaw=0., position=[0., 0.], generation=0, speed_mps=None,
                          yaw_rate_rps=None, quality='relative motion only')
        if self.generation != ego['generation']:
            self.history.clear()
            self.alert_since.clear()
            self.generation = ego['generation']
        samples = self.history.setdefault(track_id, deque(maxlen=16))
        if samples and now - samples[-1][0] > 0.6:
            samples.clear()
            self.alert_since.pop(track_id, None)
        point = rotation(ego['yaw']) @ np.array([x, z]) + np.asarray(ego['position'])
        samples.append((now, float(point[0]), float(point[1])))
        while samples and now - samples[0][0] > 1.2:
            samples.popleft()
        result = dict(x=round(x, 2), distance=round(z, 2), closing=None,
                      ttc=None, clearance=None, score=0, alert=False,
                      motion_ready=False, path=[], scooter_path=[],
                      collision_predicted=False, closest_time=None,
                      quality=ego['quality'], reason='Collecting motion samples')
        if len(samples) < 4 or now - samples[0][0] < 0.3:
            return result
        mean_t = sum(s[0] for s in samples) / len(samples)
        denominator = sum((s[0] - mean_t) ** 2 for s in samples)
        velocity = np.array([sum((s[0] - mean_t) * s[axis] for s in samples) / denominator
                             for axis in (1, 2)])
        mean_position = np.mean([[s[1], s[2]] for s in samples], axis=0)
        residual = max(np.linalg.norm(np.array(s[1:]) - mean_position - velocity * (s[0] - mean_t))
                       for s in samples)
        if residual > .35 + .025 * z or np.linalg.norm(velocity) > 60 or confidence < .45:
            self.alert_since.pop(track_id, None)
            result['reason'] = 'Unstable measurements — prediction unavailable'
            return result
        vx, vz = rotation(ego['yaw']).T @ velocity
        closing = -(vz + (ego['speed_mps'] or 0.))
        prediction = predict_collision(x, z, vx, vz, label, width, ego, self.config)
        result.update(prediction, closing=round(float(closing), 2), motion_ready=True,
                      fit_error=round(float(residual), 3), vx=float(vx), vz=float(vz),
                      object_width=float(width))
        # Cars get an earlier warning after the same stable motion fit.
        is_car = label.replace('simulated ', '') == 'car'
        threshold, confirmation = (45, .1) if is_car else (65, .3)
        eligible = prediction['collision_predicted'] and prediction['score'] >= threshold
        if eligible:
            self.alert_since.setdefault(track_id, now)
        else:
            self.alert_since.pop(track_id, None)
        result['alert'] = eligible and now - self.alert_since.get(track_id, now) >= confirmation
        result['warning_threshold'] = threshold
        result['warning_confirmation_s'] = confirmation
        return result

    def prune(self, now):
        for key in list(self.history):
            if now - self.history[key][-1][0] > 2:
                del self.history[key]
                self.alert_since.pop(key, None)


def parse_tf_frame(frame):
    """Benewake standard 9-byte UART packet, distances in centimeters."""
    if len(frame) != 9 or frame[:2] != b'YY' or sum(frame[:8]) & 255 != frame[8]:
        return None
    centimeters = int.from_bytes(frame[2:4], 'little')
    strength = int.from_bytes(frame[4:6], 'little')
    if centimeters == 0 or centimeters >= 65534 or strength < 100:
        return None
    return centimeters / 100
