"""Class-aware bounding-box association using SciPy's assignment solver."""
import numpy as np
from scipy.optimize import linear_sum_assignment


class BoxTracker:
    def __init__(self):
        self.tracks = {}
        self.next_id = 1

    def update(self, boxes, classes, timestamp):
        self.tracks = {key: value for key, value in self.tracks.items()
                       if timestamp - value[2] < .6}
        ids = list(self.tracks)
        assigned = [None] * len(boxes)
        if ids and len(boxes):
            costs = np.ones((len(ids), len(boxes)))
            for row, track_id in enumerate(ids):
                previous, label, _ = self.tracks[track_id]
                for column, box in enumerate(boxes):
                    if label != classes[column]:
                        continue
                    overlap_size = np.maximum(0, np.minimum(previous[2:], box[2:]) -
                                              np.maximum(previous[:2], box[:2]))
                    intersection = float(np.prod(overlap_size))
                    union = float(np.prod(previous[2:] - previous[:2]) +
                                  np.prod(box[2:] - box[:2]) - intersection)
                    costs[row, column] = 1 - intersection / max(union, 1)
            rows, columns = linear_sum_assignment(costs)
            for row, column in zip(rows, columns):
                if costs[row, column] < .85:
                    assigned[column] = ids[row]
        for index, box in enumerate(boxes):
            if assigned[index] is None:
                assigned[index] = self.next_id
                self.next_id += 1
            self.tracks[assigned[index]] = (box.copy(), classes[index], timestamp)
        return assigned
