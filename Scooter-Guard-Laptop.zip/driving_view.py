"""Measured rear-view scene. Road guides are illustrative, not detected lanes."""
import math
from scene_icons import draw_icon

BG = '#10151e'
MUTED = '#7f8da3'
BLUE = '#64b5ff'
RED = '#ff666e'


def render_scene(c, objects, stale=False, simulated=False):
    c.delete('all')
    w, h = max(320, c.winfo_width()), max(300, c.winfo_height())
    cx, base = w * .5, h - max(140, h * .22)
    scale = max(4, min((base - 75) / 12, (w - 100) / 17))
    def point(x, z):
        return cx + x * scale, base - z * scale
    c.create_rectangle(0, 0, w, h, fill=BG, outline='')
    c.create_text(26, 27, text='REAR SURROUNDINGS', anchor='w', fill='#edf3fc', font=('Segoe UI', 13, 'bold'))
    c.create_text(w - 24, 27, text='12 m VIEW', anchor='e', fill=MUTED, font=('Segoe UI', 10))
    # A fixed metric view avoids objects changing position when another enters.
    edge = 12 * math.tan(math.radians(34.5))
    c.create_polygon(*point(0, 0), *point(-edge, 12), *point(edge, 12), fill='#182331', outline='#293a4d')
    for z in (2, 4, 6, 8, 10, 12):
        extent = min(edge, z * math.tan(math.radians(34.5)))
        c.create_line(*point(-extent, z), *point(extent, z), fill='#253343')
        c.create_text(23, point(0, z)[1], text=f'{z} m', anchor='w', fill=MUTED, font=('Segoe UI', 9))
    for x in (-1.8, 1.8):
        c.create_line(*point(x, 0), *point(x, 12), fill='#405066', dash=(10, 12), width=2)
    c.create_polygon(*point(-.6, 4), *point(.6, 4), *point(.6, 0), *point(-.6, 0), fill='#1c3042', outline='#2a485e')
    c.create_line(*point(-3, 0), *point(3, 0), fill='#3a5872', dash=(3, 6))
    c.create_text(w-24, base+28, text='ALONGSIDE / FORWARD', anchor='e', fill=MUTED, font=('Segoe UI', 9))
    clipped = 0
    visible = sorted(objects, key=lambda o: o.get('distance') or 0, reverse=True)
    for obj in visible:
        x, z = obj.get('x'), obj.get('distance')
        if x is None or z is None or not math.isfinite(x) or not math.isfinite(z):
            continue
        if not -2.5 <= z <= 12 or abs(x * scale) > w / 2 - 30:
            clipped += 1
            continue
        px, py = point(x, z)
        color = '#8593a6' if obj.get('coasting') else RED if obj.get('alert') else '#ffca79' if obj.get('possible_turn_conflict') or (obj.get('score') or 0) >= 35 else BLUE
        uncertainty = obj.get('position_uncertainty_m',0) * scale
        if uncertainty:
            c.create_oval(px-uncertainty,py-uncertainty,px+uncertainty,py+uncertainty,outline='#76869c',dash=(3,5),width=2)
        for alternative in obj.get('turn_paths',[]):
            curve=[point(a,b) for a,b in alternative['path'] if -2.5<=b<=12 and abs(a*scale)<w/2-25]
            if len(curve)>1:
                c.create_line(*[v for p in curve for v in p],fill='#bf934f' if alternative['possible_conflict'] else '#43546a',width=1,dash=(3,6))
        if obj.get('conflict_points'):
            # Show approximate scooter-region locations, not exact contact points.
            for hit in obj['conflict_points'][::3]:
                hx,hy=point(hit['x'],hit['z'])
                if -2.5<=hit['z']<=12:
                    c.create_oval(hx-14,hy-14,hx+14,hy+14,outline='#ffc678',width=2)
            c.create_text(w/2,84,text='DASHED AMBER: ASSUMED TURN PATHS / RINGS: POSSIBLE CONFLICT REGION',fill='#ffca79',font=('Segoe UI',9,'bold'))
        path = obj.get('path', [])
        pts = [point(a, b) for a, b in path if -2.5 <= b <= 12 and abs(a * scale) < w / 2 - 25]
        if len(pts) > 1:
            c.create_line(*[v for p in pts for v in p], fill=color, width=2, dash=(5, 5), arrow='last')
        label = obj.get('label', '')
        kind = next((k for k in ('person', 'motorcycle', 'bicycle', 'truck', 'bus') if k in label), 'car')
        icon_width = max(54, min(86, int(w / 11)))
        if obj.get('alert'):
            for ring, shade in ((1.4, '#322432'), (1.1, '#56303e'), (.85, '#813b4c')):
                r = icon_width * ring * .65
                c.create_oval(px-r, py-r, px+r, py+r, outline=shade, width=2)
        draw_icon(c, px, py, kind, color, icon_width, obj.get('icon_rotation_deg',0))
        label_gap=icon_width*(.95 if obj.get('icon_rotation_deg') else .65)
        tx = px + label_gap if px < w-200 else px-label_gap
        anchor = 'w' if px < w-200 else 'e'
        title = f"{label.replace('simulated ', '').title()}  #{obj.get('id', '?')}" + (' / LAST SEEN' if obj.get('coasting') else '')
        # Label backing keeps nearby grid lines from competing with the text.
        offset = 0 if anchor == 'w' else -145
        c.create_rectangle(tx+offset-7, py-29, tx+offset+145, py+32, fill='#121e2b', outline='#2b4055')
        c.create_text(tx, py-14, text=title, fill='#e9eff8', anchor=anchor, font=('Segoe UI', 10, 'bold'))
        closing = obj.get('closing')
        if obj.get('view_orientation')=='side-view estimate':
            c.create_text(px,py+icon_width*.53,text='SIDE VIEW (EST.)',fill=MUTED,font=('Segoe UI',8,'bold'))
        detail = f'{z:.1f} m' + (f"  /  {closing:+.1f} m/s" if closing is not None else '')
        c.create_text(tx, py+9, text=detail, fill=color, anchor=anchor, font=('Segoe UI', 11, 'bold'))
        if obj.get('signal',{}).get('sides'):
            c.create_oval(px-7,py-48,px+7,py-34,fill='#ffbe64',outline='#ffe1a6')
            c.create_text(px+12,py-41,text='FLASH CANDIDATE',fill='#ffca79',anchor='w',font=('Segoe UI',8,'bold'))
    # Scooter points forward, away from the rear scene above it.
    c.create_oval(cx-43, base-43, cx+43, base+43, outline='#243e54', width=2)
    draw_icon(c, cx, base, 'scooter', BLUE, max(62, min(82, int(w/12))))
    c.create_text(cx-48, base+28, anchor='e', text='YOUR SCOOTER', fill='#e7effc', font=('Segoe UI', 10, 'bold'))
    note = 'Guides & icon sizes illustrative • vehicle heading not measured'
    c.create_text(w/2, h-14, text=note, fill=MUTED, font=('Segoe UI', 9))
    if stale or not objects:
        c.create_text(cx, h*.40, text='WAITING FOR LIVE MEASUREMENTS' if stale else 'NO OBJECTS TRACKED', fill=MUTED, font=('Segoe UI', 12, 'bold'))
    if simulated:
        c.create_text(cx, 58, text='SIMULATION · SYNTHETIC POSITIONS', fill='#ffca79', font=('Segoe UI', 11, 'bold'))
    if clipped:
        c.create_text(w-22, h-43, text=f'{clipped} outside map · see camera', anchor='e', fill='#ffca79')
