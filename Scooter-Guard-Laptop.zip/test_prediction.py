import json
import math
import sys
import threading
import time
from types import SimpleNamespace
import numpy as np

from motion import MotionInputs, rotation, telemetry_loop
from prediction import footprint_gap, predict_collision
from risk import MotionTracker


def test_footprints_overlap_and_separate():
    assert footprint_gap([0, 0], 0, [1, 2], [0, 1], .2, [1, 2]) < 0
    assert footprint_gap([0, 0], 0, [1, 2], [4, 1], .2, [1, 2]) > 0


def test_collision_occurs_before_object_reaches_center_plane():
    prediction = predict_collision(0, 6, 0, -3, 'car', 1.8, {}, {})
    assert prediction['collision_predicted']
    assert prediction['ttc'] < 2


def test_safe_overtake_has_no_overlap():
    prediction = predict_collision(4, 8, 0, -4, 'car', 1.8, {}, {})
    assert not prediction['collision_predicted']
    assert prediction['score'] == 0


def test_lateral_pedestrian_crossing_is_detected():
    prediction = predict_collision(4, .7, -1, 0, 'person', .6, {}, {})
    assert prediction['collision_predicted']
    assert 2 < prediction['ttc'] < 5


def test_turning_ego_changes_intersection():
    straight = predict_collision(0, 8, 2.5, -5, 'car', 1.8,
                                 {'speed_mps': 4, 'yaw_rate_rps': 0}, {})
    turning = predict_collision(0, 8, 2.5, -5, 'car', 1.8,
                                {'speed_mps': 4, 'yaw_rate_rps': .5}, {})
    assert not straight['collision_predicted']
    assert turning['collision_predicted']


def test_camera_rotation_alone_does_not_create_approach():
    tracker = MotionTracker()
    for n in range(21):
        timestamp = n * .1
        yaw = timestamp * .3
        relative = rotation(yaw).T @ np.array([0., 8.])
        ego = dict(yaw=yaw, position=[0, 0], generation=1, speed_mps=None,
                   yaw_rate_rps=.3, quality='yaw compensated')
        result = tracker.update(1, timestamp, *relative, ego=ego)
    assert abs(result['closing']) < .01
    assert not result['alert']


def test_equal_vehicle_and_scooter_speeds_keep_gap_constant():
    tracker = MotionTracker()
    for n in range(21):
        timestamp = n * .1
        ego = dict(yaw=0, position=[0, -3 * timestamp], generation=1,
                   speed_mps=3, yaw_rate_rps=0, quality='speed + yaw')
        result = tracker.update(1, timestamp, 0, 8, ego=ego)
    assert abs(result['closing']) < .01
    assert not result['collision_predicted']


def test_sensor_gaps_expire_and_reset_reference_frame():
    inputs = MotionInputs()
    assert inputs.ingest_json('{"speed_mps":4,"yaw_rate_rps":0.1}', 10)
    valid = inputs.advance(10)
    assert valid['speed_mps'] == 4
    assert math.isclose(valid['stopping_distance'], 7.2)
    stale = inputs.advance(12)
    assert stale['speed_mps'] is None
    assert stale['yaw_rate_rps'] is None
    assert stale['generation'] != valid['generation']


def test_invalid_sensor_values_are_rejected():
    inputs = MotionInputs()
    for line in ['[]', '{}', 'invalid', '{"speed_mps":true}',
                 '{"speed_mps":NaN}', '{"speed_mps":100}', '{"yaw_rate_rps":99}']:
        assert not inputs.ingest_json(line, 1)
    assert inputs.advance(1)['speed_mps'] is None


def test_stationary_gyro_calibration_removes_bias():
    inputs = MotionInputs()
    inputs.set_imu('BMI270')
    inputs.calibrate()
    for n in range(211):
        inputs.ingest_gyro(n * .01, [0, .02, 0])
    result = inputs.advance(2.1)
    assert abs(result['yaw_rate_rps']) < 1e-8
    assert result['quality'] == 'yaw compensated'


def test_moving_gyro_calibration_is_rejected():
    inputs = MotionInputs()
    inputs.set_imu('BMI270')
    inputs.calibrate()
    for n in range(211):
        inputs.ingest_gyro(n * .01, [0, math.sin(n / 8), 0])
    assert inputs.advance(2.1)['yaw_rate_rps'] is None


def test_unstable_depth_does_not_generate_warning():
    tracker = MotionTracker()
    for n in range(16):
        result = tracker.update(1, n * .1, 0, 5 + (2 if n % 2 else -2))
    assert not result['motion_ready']
    assert not result['alert']


def test_live_file_only_consumes_new_complete_lines(tmp_path):
    path = tmp_path / 'motion.jsonl'
    path.write_text('{"speed_mps":9}\n')
    inputs, stop = MotionInputs(), threading.Event()
    args = SimpleNamespace(motion_port=None, motion_file=str(path))
    worker = threading.Thread(target=telemetry_loop, args=(args, inputs, stop), daemon=True)
    worker.start()
    try:
        deadline = time.monotonic() + 2
        while 'file' not in inputs.input_status and time.monotonic() < deadline:
            time.sleep(.01)
        assert inputs.advance(time.monotonic())['speed_mps'] is None
        with path.open('a') as stream:
            stream.write('{"speed_mps":3.5}\n')
        deadline = time.monotonic() + 2
        while not inputs.speed_samples and time.monotonic() < deadline:
            time.sleep(.02)
        assert inputs.advance(time.monotonic())['speed_mps'] == 3.5
        assert inputs.advance(time.monotonic() + 2)['speed_mps'] is None
    finally:
        stop.set()
        worker.join(1)


def test_serial_fragments_and_warning_output(monkeypatch):
    stop = threading.Event()
    chunks = iter([b'{"speed_mps":', b'2.5}\n'])
    writes = []
    class Port:
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def read_until(self, *args, **kwargs):
            result = next(chunks)
            if result.endswith(b'\n'):
                stop.set()
            return result
        def write(self, data):
            writes.append(data)
    monkeypatch.setitem(sys.modules, 'serial', SimpleNamespace(Serial=lambda *a, **k: Port()))
    args = SimpleNamespace(motion_port='COM_TEST', motion_baud=115200, haptic_output=True)
    inputs = MotionInputs()
    telemetry_loop(args, inputs, stop, lambda: (True, False))
    assert inputs.advance(time.monotonic())['speed_mps'] == 2.5
    assert writes[-1] == b'R\n'
