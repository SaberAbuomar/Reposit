"""Experimental temporal lamp candidates and bounded motion hypotheses.

No trained lamp/orientation model is included. A blink is evidence, not a turn
command. Hypotheses use explicit assumed start times and steering rates.
"""
from collections import deque
import copy
import math
import numpy as np
from motion import rotation, scooter_position
from orientation import ViewOrientation
from prediction import DIMENSIONS, footprint_gap, predict_collision

VEHICLES = {'car', 'truck', 'bus', 'motorcycle'}

class FlashHistory:
    def __init__(self):
        self.samples = deque(maxlen=100)

    def update(self, now, value):
        if self.samples and (now <= self.samples[-1][0] or now-self.samples[-1][0] > .45):
            self.samples.clear()
        self.samples.append((now, value))
        while self.samples and now-self.samples[0][0] > 4:
            self.samples.popleft()
        if len(self.samples)<10 or now-self.samples[0][0]<1.2:
            return False
        values=np.array([v for _,v in self.samples])
        lo,hi=np.percentile(values,[15,85])
        if hi-lo < .035: return False
        threshold=lo+(hi-lo)*.5
        phases=[]
        for t,v in self.samples:
            bit=v>threshold
            if not phases or phases[-1][1]!=bit: phases.append((t,bit))
        # Complete on/off/on/off pulses, not a one-time brake-light change.
        cycles=[]
        for i in range(len(phases)-3):
            window=phases[i:i+4]
            durations=np.diff([t for t,_ in window])
            if [bit for _,bit in window]==[True,False,True,False] and np.all((durations>=.15)&(durations<=.9)):
                cycles.append(window[-1][0])
        return bool(cycles and now-cycles[-1]<=.8)

class LampObserver:
    def __init__(self):
        self.cells={}
        self.last_seen={}

    def observe(self, track_id, frame, box, now):
        import cv2
        height,width=frame.shape[:2]
        x1,y1,x2,y2=[int(v) for v in box]
        # Truncated or tiny detections cannot support a lamp interpretation.
        if x2-x1<70 or y2-y1<45 or x1<2 or y1<2 or x2>=width-2 or y2>=height-2:
            self.cells.pop(track_id,None)
            return dict(state='unavailable',note='Lamp view too small or clipped',sides=[],source='unvalidated color/blink heuristic')
        hsv=cv2.cvtColor(frame[y1:y2,x1:x2],cv2.COLOR_BGR2HSV)
        amber=((hsv[:,:,0]>=5)&(hsv[:,:,0]<=38)&(hsv[:,:,1]>110)&(hsv[:,:,2]>150)).astype(np.uint8)
        # Track fixed normalized cells, not whichever bright pixel wins each frame.
        normalized=cv2.resize(amber,(90,60),interpolation=cv2.INTER_NEAREST)
        history=self.cells.setdefault(track_id,{})
        active=[]
        for side,xbase in [('image-left',0),('image-right',60)]:
            for row in range(3):
                for col in range(2):
                    patch=normalized[15+row*15:30+row*15,xbase+col*15:xbase+(col+1)*15]
                    key=(side,row,col)
                    if history.setdefault(key,FlashHistory()).update(now,float(np.mean(patch))): active.append(side)
        self.last_seen[track_id]=now
        sides=sorted(set(active))
        state='both-side flashing candidate' if len(sides)==2 else 'flashing candidate' if sides else 'unknown'
        return dict(state=state,sides=sides,source='unvalidated amber color/blink heuristic',
                    note='Both sides flash: hazards or ambiguous lamps; turn direction unknown' if len(sides)==2 else
                         'Amber pulse candidate; vehicle orientation and turn direction unknown' if sides else
                         'No repeatable amber pulse established; red-only signals unsupported')

    def prune(self, now):
        for key in list(self.cells):
            if now-self.last_seen.get(key,-100)>1:
                self.cells.pop(key,None)
                self.last_seen.pop(key,None)


def turn_hypotheses(obj, ego, config):
    """Return alternative paths, never a claimed turn time or calibrated probability."""
    signal=obj.get('signal',{})
    empty=dict(turn_paths=[],possible_turn_conflict=False,turn_window=None,conflict_points=[],
               turn_status='No supported turning intent',turn_basis='Assumed alternatives, not observed turns')
    if not signal.get('sides') or len(signal['sides'])!=1 or not obj.get('motion_ready'):
        if len(signal.get('sides',[]))==2: empty['turn_status']='Both-side flashing: no directional turn inference'
        return empty
    speed=ego.get('speed_mps')
    stationary=bool(config.get('stationary_rig'))
    if speed is None and not stationary:
        empty['turn_status']='Turn geometry needs scooter speed or explicit stationary-rig mode'
        return empty
    if speed is not None and ego.get('yaw_rate_rps') is None and not stationary:
        empty['turn_status']='Turn geometry needs fresh scooter yaw as well as speed'
        return empty
    if stationary and ((speed is not None and abs(speed)>.2) or abs(ego.get('yaw_rate_rps') or 0)>.05):
        empty['turn_status']='Stationary setting conflicts with motion telemetry; turn paths withheld'
        return empty
    speed=0. if stationary else speed
    yaw_rate=0. if stationary else ego.get('yaw_rate_rps') or 0.
    velocity=np.array([obj.get('vx',0.),obj.get('vz',0.)],dtype=float)
    magnitude=float(np.linalg.norm(velocity))
    if magnitude<.25:
        empty['turn_status']='Vehicle movement insufficient for a turn trajectory'
        return empty
    position=np.array([obj['x'],obj['distance']],dtype=float)
    nominal_width,length=DIMENSIONS.get(obj['label'].replace('simulated ',''),(1.8,4.5))
    target_size=(max(nominal_width,obj.get('object_width',nominal_width)),length)
    margin=config.get('safety_margin',.3)+obj.get('position_uncertainty_m',0)
    scooter_size=(config.get('scooter_width',.6)+2*margin,config.get('scooter_length',1.2)+2*margin)
    center=position+np.array([0.,length/2])
    initial_yaw=math.atan2(-velocity[0],velocity[1])
    paths,collisions,points=[],[],[]
    horizon=min(4.,config.get('horizon',6.))
    # Lamp image side cannot establish vehicle-relative left/right without pose.
    for direction in (-1,1):
        for onset in (0.,.75,1.5):
            for rate in (.25,.5):
                p=position.copy()
                path=[p.round(3).tolist()]
                first=None
                for n,t in enumerate(np.arange(.1,horizon+.001,.1),1):
                    theta=direction*min(.8,max(0.,t-.05-onset)*rate)
                    p+=rotation(theta)@velocity*.1
                    target_center=p+(center-position)
                    ego_center=scooter_position(speed,yaw_rate,t)
                    gap=footprint_gap(ego_center,yaw_rate*t,scooter_size,target_center,initial_yaw+theta,target_size)
                    if gap<=0 and first is None:
                        first=float(t)
                        # Region center, not an exact bumper/body impact point.
                        points.append(dict(x=round(float(ego_center[0]),2),z=round(float(ego_center[1]),2),
                                           time_s=round(float(t),1),kind='approximate scooter conflict region'))
                    if n%3==0: path.append(p.round(3).tolist())
                if first is not None: collisions.append(first)
                paths.append(dict(path=path,assumed_start_s=onset,assumed_yaw_rate_rps=direction*rate,
                                  possible_conflict=first is not None))
    empty.update(turn_paths=paths,possible_turn_conflict=bool(collisions),conflict_points=points,
                 turn_window=[round(min(collisions),1),round(max(collisions),1)] if collisions else None,
                 turn_status='Possible conflict under assumed turn paths' if collisions else 'No overlap in tested turn alternatives',
                 turn_basis='Amber flash candidate; both turn directions tested because vehicle orientation is unknown')
    return empty

class IntentTracker:
    def __init__(self, config=None):
        self.config=config or {}
        self.lamps=LampObserver()
        self.orientation=ViewOrientation()
        self.memory={}
        self.generation=None

    def update(self, objects, frame, boxes, now, ego):
        generation=ego.get('generation',0)
        if generation!=self.generation:
            self.memory.clear()
            self.lamps=LampObserver()
            self.orientation=ViewOrientation()
            self.generation=generation
        self.lamps.prune(now)
        self.orientation.prune(now)
        visible_ids={o['id'] for o in objects if o.get('distance') is not None}
        qualified=[o for o in objects if o.get('distance') is not None]
        result=[]
        for obj in objects:
            item=dict(obj,observed=True,coasting=False,last_seen_age_s=0.,position_uncertainty_m=0.)
            label=item['label'].replace('simulated ','')
            if label in VEHICLES:
                item.update(self.orientation.observe(item['id'],label,boxes.get(item['id']),frame.shape if frame is not None else (360,640),now))
                if frame is not None and item['id'] in boxes:
                    item['signal']=self.lamps.observe(item['id'],frame,boxes[item['id']],now)
                else:
                    item.setdefault('signal',dict(state='unknown',sides=[],note='No current lamp observation'))
                if item.get('distance') is not None:
                    item.update(turn_hypotheses(item,ego,self.config))
                if item.get('motion_ready'):
                    origin=np.array([item['x'],item['distance']])
                    world=rotation(ego.get('yaw',0.))@origin+np.asarray(ego.get('position',[0,0]))
                    vel=rotation(ego.get('yaw',0.))@np.array([item['vx'],item['vz']])
                    self.memory[item['id']]=dict(item=copy.deepcopy(item),at=now,world=world,velocity=vel)
                elif item.get('distance') is not None:
                    self.memory.pop(item['id'],None)
            result.append(item)
        for key,m in list(self.memory.items()):
            age=now-m['at']
            if age>1. or age<0:
                del self.memory[key]
                continue
            if key in visible_ids: continue
            item=copy.deepcopy(m['item'])
            current=rotation(ego.get('yaw',0.)).T@(m['world']+m['velocity']*age-np.asarray(ego.get('position',[0,0])))
            velocity=rotation(ego.get('yaw',0.)).T@m['velocity']
            # Avoid drawing a duplicate ghost when an ambiguous nearby new ID appears.
            if any(o['label']==item['label'] and np.linalg.norm(current-np.array([o['x'],o['distance']]))<2. for o in qualified):
                del self.memory[key]
                continue
            item.update(x=round(float(current[0]),2),distance=round(float(current[1]),2),vx=float(velocity[0]),vz=float(velocity[1]),
                        coasting=True,observed=False,last_seen_age_s=round(age,2),position_uncertainty_m=round(.25+age*1.5,2))
            predicted=predict_collision(item['x'],item['distance'],item['vx'],item['vz'],item['label'].replace('simulated ',''),item.get('object_width',1.8),ego,self.config)
            item.update(predicted,alert=False,closing=round(-(item['vz']+(ego.get('speed_mps') or 0)),2),
                        quality='Last seen extrapolation; unobserved',reason='Unobserved projection; expires after 1 s')
            rgb_item=next((o for o in result if o['id']==key),None)
            if rgb_item is not None:
                result.remove(rgb_item)
                item['signal']=rgb_item.get('signal',item['signal'])
                item['reason']='Depth unavailable; position extrapolated for at most 1 s'
            item['observed_image']=rgb_item is not None
            item['signal']['state']='last-seen '+item['signal'].get('state','unknown')
            item['signal']['note']='No current lamp observation'
            item.update(turn_hypotheses(item,ego,self.config))
            result.append(item)
        return result
