# Scooter Guard

Laptop prototype for a rear OAK-D Lite and an optional front Benewake single-point LiDAR. All detection and threat calculations run on the laptop CPU. The OAK performs its normal stereo depth processing internally. No Jetson or cloud inference is required.

## Run on Windows

`depth_calibration.json` contains a provisional, monotonic three-reference correction. The original raw references were 2.4 m versus measured 2.134 m, and 1.9 m versus measured 1.676 m. A later adjusted reading of 1.94 m versus measured 74 inches (1.8796 m) was converted back through the previous 0.886446 scale to an inferred raw reading of 2.188514 m. Piecewise-linear interpolation passes through these three references. Beyond the reference interval, the nearest endpoint ratio is used and the desktop marks extrapolation. The correction applies to OAK depth before distance, lateral position, width, velocity, and collision calculations. Raw center readings remain visible. This empirical fit has not been independently validated at other distances, and the reported readings were rounded. Camera factory calibration is not rewritten. Remove the profile to return to raw depth. A running upgraded OAK app reloads profile changes and resets motion fits so a calibration change cannot create a false closing-speed jump.

The desktop starts with **Show depth alongside camera** enabled. The normal camera image appears on the left and its synchronized depth view on the right. Warm colors indicate nearer surfaces, cool colors indicate farther surfaces, and black indicates invalid or out-of-range depth. The large **Center distance** value is the median valid distance inside the small center square. Detected objects retain their individual distance labels and table entries in both views. Uncheck **Show depth alongside camera** for the camera image alone. This configuration accepts depth from 0.5 to 12 m, and the camera itself may produce invalid readings for nearby surfaces. Move back to about 0.8 m or more when checking distance indoors.

Double-click `Start-Laptop.bat` to open the desktop app. Select `demo` for synthetic data, `oak` for the rear depth camera, or `webcam` for laptop-camera detection. Click Start. Restart the app to change sources. The desktop app avoids browser-server connections.

Double-click `Start-OAK.bat` to launch directly into live camera mode. The project environment on this laptop has DepthAI installed and reuses the laptop's existing scientific Python packages. YOLOv8 nano weights were copied from the user's existing HackUSF project and passed a CPU inference smoke check. No detector download is required for this copy.

The OAK launcher uses USB 2 compatibility mode to address USB communication errors. Camera connection details and exceptions are recorded in `camera.log`. For a direct command, add `--usb2` to select this mode. Both RGB and stereo depth streams stay enabled.

Windows recognizes the connected camera as Movidius MyriadX with the WinUSB driver started. Live camera capture, person detection, and distance labels were verified after launching `Start-OAK.bat` directly from File Explorer. DepthAI launched from the restricted work session reports zero accessible devices, so use the File Explorer launcher. Only one app instance can use the camera at a time. No driver replacement or Windows security changes were made.

On another laptop, install dependencies with `powershell -ExecutionPolicy Bypass -File setup.ps1` from this folder with internet access.

The command `.venv\Scripts\python.exe desktop.py --mode oak --autostart --lidar-port COM3` starts the desktop interface with both inputs after installation and sensor setup.

### Optional browser interface

For the optional browser interface, run `.venv\Scripts\python.exe app.py --mode oak`, then view http://127.0.0.1:8765. Python 3.12 is recommended. Click **Enable warning sound** to permit browser audio. Local network sockets are unavailable from the restricted build session, so the desktop entry point is preferred here.

Double-click `Start-Demo.bat` for an explicitly labeled synthetic approach demonstration. Stop a running server with Ctrl+C before launching another mode.

From this folder, alternate commands are

```powershell
.venv\Scripts\python.exe app.py --mode oak
.venv\Scripts\python.exe app.py --mode demo
.venv\Scripts\python.exe app.py --mode webcam --camera 0
```

Webcam mode supports person and vehicle detection without distance or threat estimates. Demo mode uses synthetic positions. Live OAK mode reports actual detections with synchronized, RGB-aligned stereo depth.

## Optional front LiDAR

The small sensor's exact model and pinout have not been confirmed. Verify its label, voltage, and pinout before connecting it. Use a suitable USB-to-TTL adapter with the correct logic voltage. A bare sensor cannot plug directly into a laptop USB port.

The reader accepts the Benewake standard 9-byte `0x59 0x59` UART distance packet with checksum and signal-strength validation. Confirm that your model uses this protocol and its configured baud rate. It does not configure the sensor or assume a wire-color pinout.

List serial ports and start the optional reader

```powershell
.venv\Scripts\python.exe -m serial.tools.list_ports
.venv\Scripts\python.exe app.py --mode oak --lidar-port COM3 --lidar-baud 115200
```

Front warnings trigger below 1.5 m or an estimated time to contact below 2 seconds. Override the distance threshold with `--front-threshold 2.0`. Distances expire after one second without a valid reading. The front sensor provides an obstacle distance along its beam. Object classification comes from the rear camera in this arrangement.

## Threat estimate

YOLO nano detects people, bicycles, cars, motorcycles, buses, and trucks. Class-aware bounding-box overlap with SciPy assignment provides short-term track IDs. Tracks expire after 0.6 seconds without a match. This basic association can change IDs during occlusions or fast movement. The median valid depth in the central portion of each bounding box gives an approximate distance. Camera intrinsics convert horizontal pixel position into lateral meters.

A rolling linear fit estimates lateral and longitudinal velocity after at least four measurements spanning 0.3 seconds. The system now checks projected rectangular target and scooter footprints every 0.1 seconds across a six-second horizon. The first overlap time, minimum footprint gap, predicted paths, and active motion-data quality appear in the desktop app. Car warnings require a predicted overlap and score of at least 45 persisting for 0.1 seconds. Other targets retain the 65 / 0.3-second policy.

These are experimental threat scores. Accurate collision probabilities require labeled outcomes and calibration. Optional calibrated OAK gyro data compensates yaw, and wheel telemetry enables local scooter-pose and curved-path prediction. Missing inputs are labeled explicitly. The model assumes a rigid, level, rear-facing camera and short-term constant target velocity and scooter turn rate. Pitch, roll, acceleration, road slope, and exact vehicle shape remain unmodeled. Invalid depth produces an unavailable measurement. CPU load, illumination, reflective surfaces, occlusion, and USB behavior affect results. Validate using a stationary rig and controlled low-speed movement before evaluating moving-scooter behavior.

The dashboard provides visual and optional audio alerts. Included ESP32 firmware supports wheel-speed input and optional vibration-driver commands when the physical hardware is attached. No wheel sensor or vibration driver is currently connected. See `MOTION_SETUP.md` for the telemetry protocol, gyro calibration, configurable dimensions, firmware, and setup instructions.

## Dependencies

DepthAI is pinned to the v2 API used by the implementation. Live OAK operation was verified through the desktop launcher. Ultralytics YOLO software/models carry their upstream license terms, including AGPL-3.0 or an enterprise license. Review them before distributing a proprietary product.

## Presentation dashboard

The desktop now opens a driving-style rear surroundings view. Cars, trucks, bicycles, and people use distinct icons positioned using measured lateral position and depth. The fixed 12 m map shows projected paths and a scooter marker. Road guides and icon sizes are illustrative, not detected lanes or estimated vehicle heading. Objects without valid depth remain in the camera and table, but are not placed on the map. Beyond-map objects are counted explicitly. Stale frames clear the scene and camera preview.

The top cards follow the highest-risk measured object, falling back to the nearest one. Camera, Depth, and Both controls switch the sensor panel. The risk score remains an experimental score, not a crash probability. `Start-Demo.bat` now starts the same desktop dashboard with clearly labeled synthetic scenarios. `Start-OAK.bat` uses live measurements only.

## Experimental turn intent and short observation gaps

The rear-facing mounting assumption is retained. Side coverage is limited to the camera field of view. An unseen lamp provides no new evidence, and exact turn onset or physical impact location cannot be measured from a turn signal alone.

The signal recognizer is an UNVALIDATED amber color/blink heuristic, not a trained turn-signal model. It requires repeated pulses in stable image cells of a sufficiently large, untruncated vehicle detection. Red-only indicators, exact lamp identity, and vehicle-relative left/right interpretation are unsupported. Reflections, exposure changes and moving detection boxes can cause false candidates. Both-side flashing is ambiguous and does not create directional turn scenarios. Research background: https://arxiv.org/abs/1905.01333 and https://arxiv.org/abs/1906.03683 . Those learned models are not bundled.

A one-sided amber pulse candidate can generate twelve CONDITIONAL alternatives: two directions, assumed delays of 0, 0.75 and 1.5 seconds, and steering rates of 0.25 and 0.5 rad/s capped at 0.8 rad. The horizon is at most four seconds. These are assumed alternatives, not estimates of when a driver will turn or exhaustive uncertainty bounds. Nominal footprint overlaps produce a possible-conflict time range and approximate scooter-region rings, not precise impact locations. No overlap in the tested alternatives does not establish safety.

Turn geometry needs fresh scooter speed and yaw telemetry. For a physically stopped scooter only, select Stationary rig, or pass --stationary-rig. Contradictory motion telemetry suppresses stationary geometry. Conditional turn conflicts show an amber caution separately from the ordinary observed-motion warning; they do not issue new automatic audio or haptic alerts.

Previously stable vehicle positions can be extrapolated for at most ONE SECOND without depth or detection. LAST SEEN labels and expanding illustrative uncertainty rings identify these positions. The uncertainty is not statistically calibrated. Projections account for available ego translation and yaw, clear on motion-frame resets, and expire after the cap. Near ambiguous replacement IDs, old projections are suppressed to reduce duplicate ghosts. There is no verified long-term re-identification. Unobserved tracks do not issue the ordinary observed approach alarm.

Open Start-Demo.bat and click Turn demo for synthetic amber pixels, temporal detection, conditional paths, brief occlusion and expiry. Simulation is labeled. Use Start-OAK.bat for live input. Real-car signal detection and turn-conflict accuracy have NOT been validated. First record a parked car's indicators, hazards, brake lights and reflections, then measure false candidates and missed signals before controlled movement.


Car approach warnings now require a predicted footprint overlap and score >=45 sustained for 0.1 s, after the existing stable motion fit (at least four samples spanning 0.3 s). The old car policy was >=65 for 0.3 s. With the default six-second horizon, this moves the score crossing from about 2.75 s to about 3.75 s before overlap. This is algorithm timing, not a guaranteed real-world warning lead time. Non-car targets retain >=65 for 0.3 s. More sensitive car warnings may increase false alerts.

## Estimated side-view icons

Large, untruncated car, truck and bus detections now use a temporal bounding-box aspect-ratio cue to show broadside vehicles sideways on the map. At least three observations spanning 0.2 seconds are required. Median width/height >=2.1 selects the side-view symbol; <1.8 releases it. The display says SIDE VIEW (EST.). Clipped or small detections revert to unknown. The cue is not a trained vehicle pose estimator: wide frontal vehicles, partial occlusions and unusual shapes can be misclassified. The rotation is a categorical display symbol, not a measured 90-degree yaw or front/back direction. Collision geometry and signal left/right interpretation do not consume this display estimate. True heading-aware prediction still requires validated orientation estimation.


## Spoken warning output

Spoken alerts are enabled by default in the Windows desktop. Active observed approach warnings identify cars, people, trucks, buses, bikes or motorcycles. Multiple object types are combined in one message. Warnings repeat every 4.5 seconds while active. Clearing all warnings, disabling Spoken alerts, stale camera data, sensor errors or closing the dashboard cancels ongoing and queued speech. There is no speech for an ordinary detection with no alert, an unobserved ghost, or an assumed-turn caution alone. This uses Windows System.Speech and the default Windows audio output, so select the connected speaker in Windows sound settings. No extra Python package or cloud voice service is needed. The separate proximity-warning feature has not been implemented.
