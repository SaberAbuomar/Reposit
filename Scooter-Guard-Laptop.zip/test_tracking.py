import numpy as np
from tracking import BoxTracker


def test_id_persists_across_small_motion():
    tracker = BoxTracker()
    assert tracker.update(np.array([[10, 10, 100, 100]]), [2], 0) == [1]
    assert tracker.update(np.array([[12, 10, 102, 100]]), [2], .1) == [1]


def test_class_change_and_gap_create_new_ids():
    tracker = BoxTracker()
    box = np.array([[10, 10, 100, 100]])
    tracker.update(box, [2], 0)
    assert tracker.update(box, [0], .1) == [2]
    assert tracker.update(box, [0], 2) == [3]
