from risk import MotionTracker, parse_tf_frame


def trajectory(x, speed):
    tracker = MotionTracker()
    for n in range(21):
        now = n * .1
        result = tracker.update(1, now, x, 10 - speed * now)
    return tracker, result


def test_approach_warns():
    _, result = trajectory(0, 3)
    assert result['alert']
    assert result['score'] >= 65
    assert abs(result['closing'] - 3) < .01


def test_offset_pass_does_not_warn():
    _, result = trajectory(5, 3)
    assert result['score'] == 0
    assert not result['alert']


def test_receding_and_stationary_do_not_warn():
    for speed in [-2, 0]:
        _, result = trajectory(0, speed)
        assert result['score'] == 0
        assert not result['alert']


def test_gap_resets_motion_and_alert():
    tracker, _ = trajectory(0, 3)
    result = tracker.update(1, 4, 0, 3)
    assert not result['motion_ready']
    assert not result['alert']


def test_lidar_checksum_and_strength():
    packet = bytearray([89, 89, 200, 0, 150, 0, 0, 0])
    packet.append(sum(packet) & 255)
    assert parse_tf_frame(packet) == 2
    packet[8] ^= 1
    assert parse_tf_frame(packet) is None
    packet[4] = 0
    packet[8] = sum(packet[:8]) & 255
    assert parse_tf_frame(packet) is None


def test_car_warns_earlier_than_previous_policy_on_same_approach():
    tracker=MotionTracker()
    first=None
    for n in range(60):
        now=n*.05
        r=tracker.update(1,now,0,12-2*now,label='car')
        if r['alert'] and first is None:
            first=now
            assert r['collision_predicted']
            assert 45<=r['score']<65
            assert r['ttc']>3
    assert first is not None and first<2.1


def test_car_short_confirmation_still_needs_stable_motion():
    tracker=MotionTracker()
    for n in range(3):
        r=tracker.update(1,n*.1,0,5-n*.3,label='car')
        assert not r['alert']
        assert not r['motion_ready']
    for n in range(3,6):
        r=tracker.update(1,n*.1,0,5-n*.3,label='car')
    assert r['alert']
    assert r['warning_confirmation_s']==.1


def test_pedestrian_keeps_original_warning_policy():
    tracker=MotionTracker()
    for n in range(10):
        r=tracker.update(1,n*.1,0,6-n*.2,label='person')
    assert r['warning_threshold']==65
    assert r['warning_confirmation_s']==.3
