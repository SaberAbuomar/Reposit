"""Timestamped scooter motion inputs. Missing sensors remain unknown."""
from collections import deque
import json
import math
from pathlib import Path
import threading
import time

import numpy as np


def rotation(yaw):
    return np.array([[math.cos(yaw), -math.sin(yaw)],
                     [math.sin(yaw), math.cos(yaw)]])


def scooter_position(speed, yaw_rate, seconds):
    """Rear camera frame: +X image right, +Z behind. Forward travel is -Z."""
    if abs(yaw_rate) < 1e-5:
        return np.array([0., -speed * seconds])
    angle = yaw_rate * seconds
    return np.array([speed * (1 - math.cos(angle)) / yaw_rate,
                     -speed * math.sin(angle) / yaw_rate])


class MotionInputs:
    def __init__(self, axis='y', sign=1):
        self.lock = threading.Lock()
        self.axis = 'xyz'.index(axis)
        self.sign = sign
        self.speed_samples = deque(maxlen=300)
        self.external_gyro = deque(maxlen=300)
        self.gyro_samples = deque(maxlen=500)
        self.bias = None
        self.calibration = None
        self.imu_name = 'Not checked'
        self.imu_status = 'Waiting for camera'
        self.input_status = 'No wheel-speed input configured'
        self.last_time = None
        self.yaw = 0.
        self.position = np.zeros(2)
        self.last_mode = None
        self.generation = 0

    def configure(self, axis, sign):
        with self.lock:
            self.axis = 'xyz'.index(axis)
            self.sign = sign
            self.bias = None
            self.calibration = None
            self.last_mode = None

    def set_imu(self, name):
        with self.lock:
            self.imu_name = name or 'Absent'
            self.bias = None
            self.calibration = None
            self.gyro_samples.clear()
            self.imu_status = 'Uncalibrated — hold camera still and calibrate yaw' if name else 'No built-in IMU'

    def calibrate(self):
        with self.lock:
            if self.imu_name in ('Absent', 'Not checked'):
                return
            self.calibration = []
            self.bias = None
            self.imu_status = 'Calibrating — keep the camera still for 2 seconds'

    def ingest_gyro(self, timestamp, xyz):
        vector = np.asarray(xyz, dtype=float)
        if not np.isfinite(vector).all() or np.linalg.norm(vector) > 20:
            return
        with self.lock:
            if self.gyro_samples and timestamp <= self.gyro_samples[-1][0]:
                return
            self.gyro_samples.append((timestamp, vector))
            if self.calibration is not None:
                self.calibration.append((timestamp, vector))
                if timestamp - self.calibration[0][0] >= 2 and len(self.calibration) >= 80:
                    values = np.array([sample[1] for sample in self.calibration])
                    if np.max(np.std(values, axis=0)) < .025 and np.linalg.norm(np.mean(values, axis=0)) < .25:
                        self.bias = np.mean(values, axis=0)
                        self.imu_status = 'Yaw calibrated'
                    else:
                        self.imu_status = 'Calibration rejected — hold still and try again'
                    self.calibration = None

    def ingest_json(self, line, timestamp=None):
        timestamp = time.monotonic() if timestamp is None else timestamp
        try:
            payload = json.loads(line)
            if not isinstance(payload, dict):
                return False
            accepted = False
            with self.lock:
                for key, destination, limit in [('speed_mps', self.speed_samples, 30),
                                                 ('yaw_rate_rps', self.external_gyro, 3)]:
                    value = payload.get(key)
                    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and abs(value) <= limit:
                        if destination and timestamp <= destination[-1][0]:
                            continue
                        destination.append((timestamp, float(value)))
                        accepted = True
            return accepted
        except (ValueError, TypeError):
            return False

    @staticmethod
    def fresh(samples, timestamp, max_age):
        return next((value for at, value in reversed(samples)
                     if 0 <= timestamp - at <= max_age), None)

    def advance(self, timestamp, reaction=1., deceleration=2.5):
        with self.lock:
            speed = self.fresh(self.speed_samples, timestamp, 1.)
            yaw_rate = self.fresh(self.external_gyro, timestamp, .5)
            gyro_source = 'external' if yaw_rate is not None else None
            if yaw_rate is None and self.bias is not None:
                samples = [value for at, value in self.gyro_samples if 0 <= timestamp - at <= .15]
                if samples:
                    yaw_rate = float((np.mean(samples, axis=0)[self.axis] - self.bias[self.axis]) * self.sign)
                    gyro_source = self.imu_name
            mode = (speed is not None, gyro_source)
            dt = timestamp - self.last_time if self.last_time is not None else 0
            if mode != self.last_mode or not 0 <= dt <= .6:
                self.generation += 1
                self.yaw = 0.
                self.position = np.zeros(2)
                dt = 0
            angular_speed = yaw_rate if yaw_rate is not None else 0.
            if speed is not None:
                self.position += rotation(self.yaw) @ scooter_position(speed, angular_speed, dt)
            self.yaw += angular_speed * dt
            self.last_time = timestamp
            self.last_mode = mode
            full = speed is not None and yaw_rate is not None
            return dict(speed_mps=speed, yaw_rate_rps=yaw_rate, yaw=self.yaw,
                        position=self.position.tolist(), generation=self.generation,
                        quality='speed + yaw' if full else 'yaw compensated' if yaw_rate is not None else 'speed only' if speed is not None else 'relative motion only',
                        gyro_source=gyro_source, imu=self.imu_name, imu_status=self.imu_status,
                        gyro_axis='xyz'[self.axis], gyro_sign=self.sign,
                        input_status=self.input_status,
                        stopping_distance=(abs(speed) * reaction + speed ** 2 / (2 * deceleration)) if speed is not None else None)


def add_motion_arguments(parser):
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--motion-port', help='USB serial port carrying newline JSON scooter telemetry')
    group.add_argument('--motion-file', help='Append-only newline JSON telemetry file')
    parser.add_argument('--motion-baud', type=int, default=115200)
    parser.add_argument('--gyro-axis', choices=['x', 'y', 'z'], default='y')
    parser.add_argument('--gyro-sign', type=int, choices=[-1, 1], default=1)
    parser.add_argument('--reaction-time', type=float, default=1.)
    parser.add_argument('--deceleration', type=float, default=2.5)
    parser.add_argument('--scooter-width', type=float, default=.6)
    parser.add_argument('--scooter-length', type=float, default=1.2)
    parser.add_argument('--safety-margin', type=float, default=.3)
    parser.add_argument('--horizon', type=float, default=6.)
    parser.add_argument('--stationary-rig', action='store_true', help='Explicitly assume the scooter is stationary for turn scenarios')
    parser.add_argument('--haptic-output', action='store_true', help='Send warning commands to an attached motion serial board')


def validate_motion_arguments(parser, args):
    positive = (args.deceleration, args.horizon, args.scooter_width, args.scooter_length)
    nonnegative = (args.safety_margin, args.reaction_time)
    if any(not math.isfinite(value) or value <= 0 for value in positive) or any(
            not math.isfinite(value) or value < 0 for value in nonnegative):
        parser.error('Prediction dimensions, horizon, and deceleration must be finite and positive; margins and reaction time must be finite and nonnegative.')
    if args.haptic_output and not args.motion_port:
        parser.error('--haptic-output requires an attached board selected with --motion-port.')


def telemetry_loop(args, inputs, stop, alert_provider=None):
    """Only complete new lines refresh readings. EOF never refreshes old data."""
    try:
        if args.motion_port:
            import serial
            with serial.Serial(args.motion_port, args.motion_baud, timeout=.2) as source:
                inputs.input_status = f'Wheel input {args.motion_port}'
                pending = bytearray()
                while not stop.is_set():
                    pending.extend(source.read_until(b'\n', size=1024))
                    while b'\n' in pending:
                        line, _, remainder = pending.partition(b'\n')
                        pending = bytearray(remainder)
                        if len(line) <= 1024:
                            inputs.ingest_json(line.decode('utf-8', errors='replace'))
                    if len(pending) > 1024:
                        pending.clear()
                    if args.haptic_output and alert_provider:
                        rear, front = alert_provider()
                        command = 'B' if rear and front else 'R' if rear else 'F' if front else '0'
                        source.write((command + '\n').encode('ascii'))
        elif args.motion_file:
            path = Path(args.motion_file)
            # Skip old file contents rather than presenting old measurements as live.
            position = path.stat().st_size if path.exists() else 0
            inputs.input_status = f'Wheel input file {path.name}'
            while not stop.wait(.05):
                if not path.exists():
                    continue
                if path.stat().st_size < position:
                    position = 0
                with path.open('r', encoding='utf-8') as source:
                    source.seek(position)
                    while True:
                        start = source.tell()
                        line = source.readline(1024)
                        if not line or not line.endswith('\n'):
                            position = start
                            break
                        position = source.tell()
                        inputs.ingest_json(line)
    except Exception as exc:
        inputs.input_status = f'Wheel input unavailable: {exc}'
