@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe -c "import depthai, fastapi, PIL, ultralytics, scipy" >nul 2>&1
if errorlevel 1 powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
if errorlevel 1 goto failed
.venv\Scripts\python.exe desktop.py --mode oak --autostart --usb2 %*
pause
exit /b
:failed
echo Setup failed. Check internet access and try again.
pause
