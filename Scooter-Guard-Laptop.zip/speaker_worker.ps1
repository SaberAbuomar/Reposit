$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$speaker = New-Object System.Speech.Synthesis.SpeechSynthesizer
$speaker.SetOutputToDefaultAudioDevice()
$speaker.Volume = 100
$speaker.Rate = 1
try {
    while ($null -ne ($line = [Console]::In.ReadLine())) {
        $command = $line | ConvertFrom-Json
        # Cancel the current utterance and queued speech on every state change.
        $speaker.SpeakAsyncCancelAll()
        if ($command.action -eq 'speak' -and $command.text) {
            [void] $speaker.SpeakAsync([string] $command.text)
        }
    }
} finally {
    $speaker.SpeakAsyncCancelAll()
    $speaker.Dispose()
}
