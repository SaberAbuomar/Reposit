"""Checks for temporal evidence, bounded coasting and conditional conflict geometry."""
import copy
import numpy as np
import pytest
from intent import FlashHistory, LampObserver, IntentTracker, turn_hypotheses
from risk import MotionTracker

def ego(generation=0, **kw):
    return dict(dict(yaw=0.,position=[0.,0.],generation=generation,speed_mps=None,yaw_rate_rps=None,quality='relative motion only'),**kw)

def car(**kw):
    return dict(dict(id=1,label='car',x=3.,distance=5.,vx=0.,vz=-2.,motion_ready=True,score=0,alert=False,
                     object_width=1.8,signal={'state':'flashing candidate','sides':['image-left']}),**kw)

def test_repeated_flash_required_not_constant_or_one_brake_change():
    for series in ([.2]*40,[0.]*20+[.2]*20):
        h=FlashHistory()
        assert not any(h.update(i*.1,v) for i,v in enumerate(series))
    h=FlashHistory()
    results=[h.update(i*.1,.2 if (i//4)%2==0 else 0.) for i in range(40)]
    assert any(results)
    assert not h.update(10.,.2)

def test_amber_visible_blink_candidate_and_hazards():
    o=LampObserver()
    for i in range(36):
        frame=np.zeros((160,240,3),dtype=np.uint8)
        if (i//4)%2==0:
            frame[75:90,45:60]=[0,190,255]
        s=o.observe(1,frame,[30,30,210,150],i*.1)
    assert s['sides']==['image-left']
    assert 'candidate' in s['state']
    o=LampObserver()
    for i in range(36):
        frame=np.zeros((160,240,3),dtype=np.uint8)
        if (i//4)%2==0:
            frame[75:90,45:60]=[0,190,255]
            frame[75:90,180:195]=[0,190,255]
        s=o.observe(1,frame,[30,30,210,150],i*.1)
    assert len(s['sides'])==2
    assert 'unknown' in s['note']
    assert not turn_hypotheses(car(signal=s),ego(),{'stationary_rig':True})['turn_paths']

def test_small_clipped_and_red_lamps_remain_unknown():
    o=LampObserver()
    frame=np.zeros((160,240,3),dtype=np.uint8)
    assert o.observe(1,frame,[0,0,30,30],0)['state']=='unavailable'
    for i in range(40):
        frame[:]=0
        if (i//4)%2==0: frame[75:90,45:60]=[0,0,255]
        s=o.observe(1,frame,[30,30,210,150],i*.1)
    assert not s['sides']

def test_conditional_paths_require_ego_motion_or_explicit_stationary():
    assert not turn_hypotheses(car(),ego(),{})['turn_paths']
    assert not turn_hypotheses(car(),ego(speed_mps=3.),{})['turn_paths']
    r=turn_hypotheses(car(),ego(),{'stationary_rig':True})
    assert len(r['turn_paths'])==12
    assert r['possible_turn_conflict']
    assert r['turn_window'][0]<=r['turn_window'][1]
    assert {p['assumed_start_s'] for p in r['turn_paths']}=={0.,.75,1.5}
    assert any(p['assumed_yaw_rate_rps']<0 for p in r['turn_paths'])
    assert any(p['assumed_yaw_rate_rps']>0 for p in r['turn_paths'])
    assert not turn_hypotheses(car(),ego(speed_mps=3.,yaw_rate_rps=0),{'stationary_rig':True})['turn_paths']

def test_no_signal_no_turn_and_stationary_target_no_invented_movement():
    assert not turn_hypotheses(car(signal={'sides':[]}),ego(),{'stationary_rig':True})['turn_paths']
    assert not turn_hypotheses(car(vz=0.),ego(),{'stationary_rig':True})['turn_paths']

def test_coasting_expires_and_does_not_emit_observed_alert():
    tracker=IntentTracker()
    tracker.update([car(alert=True)],None,{},0,ego())
    projected=tracker.update([],None,{},.5,ego())[0]
    assert projected['coasting'] and not projected['observed']
    assert projected['distance']==4.
    assert projected['position_uncertainty_m']>0
    assert not projected['alert']
    assert tracker.update([],None,{},1.01,ego())==[]

def test_ego_translation_and_yaw_applied_to_unseen_projection():
    tracker=IntentTracker()
    tracker.update([car(x=0.)],None,{},0,ego())
    p=tracker.update([],None,{},.5,ego(position=[0.,-1.],yaw=np.pi/2))[0]
    assert p['x']==pytest.approx(5.)
    assert p['distance']==pytest.approx(0.,abs=.01)

def test_generation_change_and_nearby_new_id_remove_ghost():
    tracker=IntentTracker()
    tracker.update([car()],None,{},0,ego())
    assert tracker.update([],None,{},.5,ego(generation=1))==[]
    tracker.update([car()],None,{},1,ego())
    new=car(id=2,distance=4.)
    assert len(tracker.update([new],None,{},1.5,ego()))==1

def test_weak_measurement_invalidates_memory():
    tracker=IntentTracker()
    tracker.update([car()],None,{},0,ego())
    tracker.update([car(motion_ready=False)],None,{},.1,ego())
    assert tracker.update([],None,{},.2,ego())==[]

def test_fitted_velocity_is_exported_for_motion_memory():
    tracker=MotionTracker()
    for i in range(10): r=tracker.update(1,i*.1,3,6-i*.2,label='car')
    assert r['motion_ready']
    assert r['vz']==pytest.approx(-2.)


def test_demo_fourth_scenario_exercises_pixel_flash_and_paths(monkeypatch):
    import app
    class Stop:
        count=0
        def wait(self, interval):
            self.count+=1
            return self.count>45
    monkeypatch.setattr(app,'state',{})
    times=iter([0.]+[36.+i*.1 for i in range(45)])
    monkeypatch.setattr(app,'stop',Stop())
    monkeypatch.setattr(app.time,'monotonic',lambda:next(times))
    captured=[]
    monkeypatch.setattr(app,'publish',lambda frame,objects,*a,**kw:captured.extend(objects))
    app.demo_loop()
    assert any(o.get('signal',{}).get('sides') for o in captured)
    assert any(o.get('turn_paths') for o in captured)
    assert any(o.get('possible_turn_conflict') for o in captured)


def test_visible_rgb_without_depth_coasts_then_expires():
    tracker=IntentTracker()
    tracker.update([car()],None,{},0,ego())
    invalid=car(distance=None,x=None,motion_ready=False)
    result=tracker.update([invalid],None,{},.5,ego())
    assert len(result)==1
    assert result[0]['coasting'] and result[0]['observed_image']
    assert result[0]['distance']==4.
    expired=tracker.update([invalid],None,{},1.1,ego())
    assert len(expired)==1 and expired[0]['distance'] is None
