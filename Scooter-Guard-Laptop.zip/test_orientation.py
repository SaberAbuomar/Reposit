from orientation import ViewOrientation
from scene_icons import sprite

def test_side_view_requires_consistent_history_and_rotates_display():
    observer=ViewOrientation()
    for n in range(4): r=observer.observe(1,'car',[100,100,400,210],(360,640),n*.1)
    assert r['icon_rotation_deg']==90
    assert r['view_orientation']=='side-view estimate'
    assert 'front/back' in r['orientation_note']

def test_front_view_does_not_invent_heading():
    observer=ViewOrientation()
    for n in range(5): r=observer.observe(1,'car',[100,100,240,220],(360,640),n*.1)
    assert r['icon_rotation_deg']==0
    assert r['view_orientation']=='unknown'

def test_clipped_car_and_stale_tracks_clear_estimate():
    observer=ViewOrientation()
    for n in range(4): observer.observe(1,'car',[100,100,400,210],(360,640),n*.1)
    assert observer.observe(1,'car',[0,100,400,210],(360,640),.4)['view_orientation']=='unknown'
    assert observer.observe(1,'car',[100,100,400,210],(360,640),1.4)['view_orientation']=='unknown'
    observer.prune(3.)
    assert not observer.tracks

def test_rotated_car_asset_has_horizontal_silhouette():
    im=sprite('car','#64b5ff',80).rotate(90,expand=True)
    assert im.width>im.height
