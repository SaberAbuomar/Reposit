"""Application-level empirical scale correction. Factory calibration is untouched."""
from dataclasses import dataclass
import json
import math
from pathlib import Path
import numpy as np


@dataclass(frozen=True)
class DepthCalibration:
    factor: float = 1.
    raw_min: float = 0.
    raw_max: float = math.inf
    count: int = 0
    knots: tuple = ()
    method: str = 'scale'

    @classmethod
    def from_samples(cls, samples, method='scale'):
        if method == 'least-squares proportional scale through zero':
            method = 'scale'
        if method not in ('scale', 'piecewise-linear'):
            raise ValueError('Unsupported depth correction method.')
        if len(samples) < 2:
            raise ValueError('At least two distance references are required.')
        pairs = [(float(s['reported_m']), float(s['measured_m'])) for s in samples]
        if any(not math.isfinite(v) or v <= 0 for pair in pairs for v in pair):
            raise ValueError('Distance references must be finite and positive.')
        raw = [r for r, actual in pairs]
        pairs.sort()
        if any(right[0] <= left[0] or right[1] <= left[1]
               for left, right in zip(pairs, pairs[1:])):
            raise ValueError('Distance references must increase in both raw and measured distance.')
        if max(raw) - min(raw) < .25:
            raise ValueError('Distance references must span at least 0.25 m to estimate a scale.')
        ratios = [actual / r for r, actual in pairs]
        if max(ratios) / min(ratios) > 1.05:
            raise ValueError('Reference readings do not support a consistent proportional correction.')
        factor = sum(r * actual for r, actual in pairs) / sum(r * r for r, actual in pairs)
        return cls(factor, min(raw), max(raw), len(pairs), tuple(pairs), method)

    @classmethod
    def load(cls, path):
        path = Path(path)
        if not path.exists():
            return cls()
        payload = json.loads(path.read_text(encoding='utf-8'))
        return cls.from_samples(payload['references'], payload.get('method', 'scale'))

    def correct(self, raw_m):
        if self.method == 'piecewise-linear':
            return self.interpolate(raw_m, self.knots)
        return raw_m * self.factor

    def raw_for_corrected(self, adjusted_m):
        if self.method == 'piecewise-linear':
            return self.interpolate(adjusted_m, [(actual, raw) for raw, actual in self.knots])
        return adjusted_m / self.factor

    @staticmethod
    def interpolate(values, knots):
        source, target = np.asarray(knots).T
        array = np.asarray(values)
        corrected = np.interp(array, source, target)
        # Endpoint ratios keep the mapping continuous and positive outside the
        # tested interval, while the UI explicitly marks extrapolation.
        corrected = np.where(array < source[0], array * target[0] / source[0], corrected)
        corrected = np.where(array > source[-1], array * target[-1] / source[-1], corrected)
        return float(corrected) if array.ndim == 0 else corrected

    def describe(self, raw_m=None):
        return dict(factor=self.factor, method=self.method, reference_count=self.count,
                    provisional=self.count > 0,
                    raw_range=[self.raw_min, self.raw_max] if self.count else None,
                    extrapolated=bool(self.count and raw_m is not None and
                                      not self.raw_min <= raw_m <= self.raw_max))
