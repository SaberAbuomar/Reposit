import math
import pytest
from depth_measurement import DepthCalibration


def test_user_reference_fit():
    calibration = DepthCalibration.from_samples([
        {'reported_m': 2.4, 'measured_m': 2.134},
        {'reported_m': 1.9, 'measured_m': 1.676}])
    assert abs(calibration.correct(2.4) - 2.134) < .01
    assert abs(calibration.correct(1.9) - 1.676) < .01
    assert calibration.describe(4)['extrapolated']
    assert not calibration.describe(2)['extrapolated']


def test_missing_profile_uses_raw_distances(tmp_path):
    calibration = DepthCalibration.load(tmp_path / 'missing.json')
    assert calibration.correct(2.4) == 2.4
    assert not calibration.describe()['provisional']


def test_inconsistent_or_invalid_references_rejected():
    for bad in [math.nan, math.inf, -1, 0]:
        with pytest.raises(ValueError):
            DepthCalibration.from_samples([{'reported_m': bad, 'measured_m': 1},
                                           {'reported_m': 3, 'measured_m': 2}])
    with pytest.raises(ValueError):
        DepthCalibration.from_samples([{'reported_m': 1, 'measured_m': 1},
                                       {'reported_m': 3, 'measured_m': 1}])


@pytest.mark.parametrize('method', ['scale', 'piecewise-linear'])
def test_processing_uses_corrected_depth_for_center_and_tracks(monkeypatch, method):
    import numpy as np
    import torch
    from types import SimpleNamespace
    import app
    from risk import MotionTracker
    from tracking import BoxTracker

    calibration = DepthCalibration.from_samples([
        {'reported_m': 2.4, 'measured_m': 2.134},
        {'reported_m': 1.9, 'measured_m': 1.676}], method=method)
    box = SimpleNamespace(xyxy=torch.tensor([[100., 50., 300., 300.]]),
                          cls=torch.tensor([2]), conf=torch.tensor([.9]))
    class Boxes:
        xyxy = box.xyxy
        cls = box.cls
        def __iter__(self):
            return iter([box])
    model = SimpleNamespace(names={2: 'car'},
                            predict=lambda *args, **kwargs: [SimpleNamespace(boxes=Boxes())])
    tracker = MotionTracker()
    tracker.boxes = BoxTracker()
    monkeypatch.setattr(app, 'depth_calibration', calibration)
    monkeypatch.setattr(app, 'state', {})
    app.process_frame(model, tracker, np.zeros((360, 640, 3), dtype=np.uint8),
                      np.full((360, 640), 1900, dtype=np.uint16),
                      [[400, 0, 320], [0, 400, 180], [0, 0, 1]], 1., 'oak')
    assert app.state['center_distance'] == pytest.approx(calibration.correct(1.9), abs=1e-6)
    assert app.state['center_raw_distance'] == pytest.approx(1.9, abs=1e-6)
    assert app.state['objects'][0]['distance'] == pytest.approx(1.68, abs=.01)
    assert app.state['objects'][0]['distance_raw'] == 1.9


def test_third_reference_uses_raw_equivalent_of_adjusted_reading():
    references = [{'reported_m': 2.4, 'measured_m': 2.134},
                  {'reported_m': 1.9, 'measured_m': 1.676}]
    previous = DepthCalibration.from_samples(references)
    raw = previous.raw_for_corrected(1.94)
    references.append({'reported_m': raw, 'measured_m': 74 * .0254})
    revised = DepthCalibration.from_samples(references, method='piecewise-linear')
    assert revised.correct(raw) == pytest.approx(1.8796)
    assert revised.correct(1.9) == pytest.approx(1.676)
    assert revised.correct(2.4) == pytest.approx(2.134)
    assert revised.raw_for_corrected(revised.correct(raw)) == pytest.approx(raw)


def test_interpolation_is_continuous_monotonic_and_supports_depth_arrays():
    import numpy as np
    calibration = DepthCalibration.from_samples([
        {'reported_m': 1.9, 'measured_m': 1.676},
        {'reported_m': 2.1885143269925353, 'measured_m': 1.8796},
        {'reported_m': 2.4, 'measured_m': 2.134}], method='piecewise-linear')
    values = np.linspace(0, 5, 200).reshape(10, 20)
    corrected = calibration.correct(values)
    assert corrected.shape == values.shape
    assert np.all(np.diff(corrected.ravel()) > 0)
    for raw, actual in calibration.knots:
        assert abs(calibration.correct(raw - 1e-7) - actual) < 1e-6
        assert abs(calibration.correct(raw + 1e-7) - actual) < 1e-6
