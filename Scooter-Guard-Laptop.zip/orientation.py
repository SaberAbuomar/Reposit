"""Image-shape side-view cue for display only; not a vehicle pose model."""
from collections import deque
import statistics

class ViewOrientation:
    def __init__(self):
        self.tracks={}

    def observe(self, track_id, label, box, shape, now):
        unknown=dict(icon_rotation_deg=0,view_orientation='unknown',orientation_note='Vehicle heading unknown')
        if label not in ('car','truck','bus') or box is None: return unknown
        x1,y1,x2,y2=map(float,box)
        h,w=shape[:2]
        bw,bh=x2-x1,y2-y1
        if bw<60 or bh<35 or x1<3 or y1<3 or x2>w-3 or y2>h-3:
            self.tracks.pop(track_id,None)
            return dict(unknown,orientation_note='Vehicle view clipped or too small; heading unknown')
        previous=self.tracks.get(track_id)
        if previous is None or now-previous['at']>.5 or now<=previous['at']:
            previous=dict(samples=deque(maxlen=6),at=now,side=False)
            self.tracks[track_id]=previous
        previous['samples'].append((now,bw/bh))
        previous['at']=now
        samples=previous['samples']
        if len(samples)<3 or now-samples[0][0]<.2: return unknown
        ratio=statistics.median(r for _,r in samples)
        # Hysteresis suppresses flicker. Shape is only a broadside cue.
        if ratio>=2.1: previous['side']=True
        elif ratio<1.8: previous['side']=False
        if previous['side']:
            return dict(icon_rotation_deg=90,view_orientation='side-view estimate',
                        orientation_note='Side view estimated from image shape; front/back and exact heading unknown')
        return unknown

    def prune(self,now):
        for key in list(self.tracks):
            if now-self.tracks[key]['at']>1: del self.tracks[key]
