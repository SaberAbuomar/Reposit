"""Antialiased top-view symbols. Position is measured; icon heading is illustrative."""
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFilter, ImageTk

@lru_cache(maxsize=96)
def sprite(kind, color, width):
    scale=3
    im=Image.new('RGBA',(128*scale,200*scale))
    d=ImageDraw.Draw(im)
    def box(bounds,fill,r=0,outline=None,width=1):
        b=tuple(int(v*scale) for v in bounds)
        if r: d.rounded_rectangle(b,radius=r*scale,fill=fill,outline=outline,width=width*scale)
        else: d.rectangle(b,fill=fill,outline=outline,width=width*scale)
    def poly(points,fill): d.polygon([(x*scale,y*scale) for x,y in points],fill=fill)
    def line(points,fill,width=2): d.line([(x*scale,y*scale) for x,y in points],fill=fill,width=width*scale)
    def oval(bounds,fill,outline=None,width=1): d.ellipse(tuple(int(v*scale) for v in bounds),fill=fill,outline=outline,width=width*scale)
    # Soft ground shadow is baked into each symbol.
    shadow=Image.new('RGBA',im.size)
    ImageDraw.Draw(shadow).ellipse((24*scale,19*scale,111*scale,192*scale),fill=(0,0,0,160))
    shadow=shadow.filter(ImageFilter.GaussianBlur(6*scale))
    if kind=='scooter':
        box((57,22,71,61),'#090e17',6)
        box((57,145,71,184),'#090e17',6)
        box((47,65,81,159),'#6c8499',14)
        box((51,70,77,153),'#dce8f3',11)
        box((56,77,72,145),'#849eb4',6)
        line([(64,145),(64,175)],'#edf4fc',6)
        box((27,157,101,166),'#c5d8e8',4)
        box((21,155,38,168),'#293d51',4)
        box((90,155,107,168),'#293d51',4)
        oval((47,82,81,116),'#3e5d7b')
        oval((52,84,76,107),'#f0f5fb')
        box((56,29,72,35),'#ff6475',3)
        box((56,173,72,178),'#e2f5ff',2)
    elif kind=='person':
        oval((32,84,96,131),'#dce8f3')
        line([(44,113),(37,154)],'#91aec7',13)
        line([(84,113),(91,154)],'#91aec7',13)
        box((45,113,61,167),'#6c8ca9',7)
        box((67,113,83,167),'#6c8ca9',7)
        oval((43,61,85,104),'#eaf2fb')
        oval((48,63,80,85),'#9ab9d2')
        line([(42,111),(86,111)],color,4)
    elif kind in ('bicycle','motorcycle'):
        oval((53,22,75,66),'#0a111b', '#91a7bd',2)
        oval((53,143,75,187),'#0a111b','#91a7bd',2)
        line([(64,47),(64,166)],'#b7cadc',5)
        if kind=='motorcycle':
            box((43,70,85,140),'#c5d8e8',14)
            box((50,96,78,139),'#30495f',10)
            poly([(45,74),(52,52),(76,52),(83,74)],'#7597b2')
        else:
            line([(64,72),(44,115),(64,140),(82,102),(64,72)],color,5)
            box((51,112,77,125),'#dce8f3',5)
        line([(35,65),(93,65)],'#dce8f3',5)
        box((30,62,43,69),'#4e657b',3)
        box((85,62,98,69),'#4e657b',3)
    else:
        truck=kind=='truck'
        bus=kind=='bus'
        for x in (23,93):
            box((x,48,x+12,80),'#080e16',4)
            box((x,130,x+12,163),'#080e16',4)
        box((30,22,98,179),'#8198ad',18, '#d2e2f0')
        box((34,25,94,175),'#d9e5ef',15)
        box((36,29,92,62),'#edf4fa',10)
        box((20,72,36,82),'#b1c7da',4)
        box((92,72,108,82),'#b1c7da',4)
        if truck:
            box((36,75,92,164),'#8099af',5)
            for x in range(43,90,10): line([(x,84),(x,156)],'#adc1d1',2)
            box((40,41,88,66),'#253c52',6)
        elif bus:
            box((39,41,89,66),'#21384d',5)
            box((40,77,88,159),'#abc0d1',5)
            for y in (83,110,138): box((46,y,82,y+15),'#4b667e',3)
        else:
            poly([(40,69),(88,69),(82,99),(46,99)],'#233b52')
            line([(44,73),(84,73)],'#698eae',2)
            box((46,104,82,136),'#c1d2e0',8)
            poly([(46,140),(82,140),(87,157),(41,157)],'#2e4961')
            line([(36,88),(36,143)],'#9fb6ca',2)
            line([(92,88),(92,143)],'#9fb6ca',2)
        box((39,30,54,35),'#effaff',2)
        box((74,30,89,35),'#effaff',2)
        box((36,164,51,170),'#ff6678',2)
        box((77,164,92,170),'#ff6678',2)
        box((51,174,77,178),'#536d84',2)
        line([(34,42),(34,157)],color,2)
        line([(94,42),(94,157)],color,2)
    shadow.alpha_composite(im)
    return shadow.resize((width,round(width*200/128)),Image.Resampling.LANCZOS)


def draw_icon(canvas,x,y,kind,color,width,rotation_deg=0):
    if not hasattr(canvas,'_sprite_cache'): canvas._sprite_cache={}
    key=(kind,color,width,int(rotation_deg))
    if key not in canvas._sprite_cache:
        canvas._sprite_cache[key]=ImageTk.PhotoImage(sprite(kind,color,width).rotate(rotation_deg,expand=True,resample=Image.Resampling.BICUBIC),master=canvas)
    canvas.create_image(x,y,image=canvas._sprite_cache[key])
