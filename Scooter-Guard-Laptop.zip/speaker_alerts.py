"""Cancellable spoken warning output using the Windows default audio device."""
import json
import logging
from pathlib import Path
import subprocess
import sys
import time


def warning_phrase(objects, front=None, stale=False, error=False):
    if stale or error:
        return None
    labels = {o.get('label', '').replace('simulated ', '') for o in objects
              if o.get('alert') and not o.get('coasting')}
    names = [name for name in ('car', 'person', 'truck', 'bus', 'motorcycle', 'bicycle') if name in labels]
    parts = []
    if names:
        parts.append(' and '.join(names) + ' approaching')
    if front and front.get('alert'):
        parts.append('obstacle ahead')
    if labels and not names:
        parts.append('object approaching')
    return 'Warning. ' + '. '.join(parts) + '.' if parts else None


class SpokenWarnings:
    def __init__(self, repeat_seconds=4.5, clock=time.monotonic, factory=None):
        self.repeat_seconds = repeat_seconds
        self.clock = clock
        self.factory = factory
        self.process = None
        self.current = None
        self.next_repeat = 0.
        self.retry_at = 0.
        self.error = None
        self.closed = False

    def _send(self, action, text=''):
        try:
            if self.process is None or self.process.poll() is not None:
                if action != 'speak' or self.clock() < self.retry_at:
                    return False
                if self.factory:
                    self.process = self.factory()
                elif sys.platform == 'win32':
                    self.process = subprocess.Popen(
                        ['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
                         '-File', str(Path(__file__).with_name('speaker_worker.ps1'))],
                        stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        text=True, encoding='utf-8', creationflags=subprocess.CREATE_NO_WINDOW)
                else:
                    self.error = 'Spoken alerts currently require Windows'
                    return False
            self.process.stdin.write(json.dumps(dict(action=action, text=text)) + '\n')
            self.process.stdin.flush()
            self.error = None
            return True
        except (OSError, ValueError) as exc:
            self.error = 'Speaker output unavailable'
            logging.warning('Spoken warning output failed: %s', exc)
            self.retry_at = self.clock() + 5
            if self.process is not None:
                try:
                    self.process.terminate()
                except OSError:
                    pass
            self.process = None
            return False

    def update(self, phrase, enabled=True):
        if self.closed:
            return
        if self.process is not None and self.process.poll() is not None:
            self.error = 'Speaker output unavailable'
        target = phrase if enabled else None
        now = self.clock()
        if target != self.current:
            self.current = target
            if target is None:
                self._send('cancel')
                self.next_repeat = 0.
            else:
                self._send('speak', target)
                self.next_repeat = now + self.repeat_seconds
        elif target and now >= self.next_repeat:
            self._send('speak', target)
            self.next_repeat = now + self.repeat_seconds

    def close(self):
        self.current = None
        self.closed = True
        self._send('cancel')
        if self.process is not None:
            try:
                self.process.stdin.close()
                self.process.terminate()
            except (OSError, ValueError):
                pass
            self.process = None
