/* ESP32 wheel-speed telemetry and optional vibration driver output.
   Measure WHEEL_CIRCUMFERENCE_M and set PULSES_PER_REV for your wheel.
   GPIO27 accepts a 3.3V-compatible/open-collector Hall sensor signal.
   GPIO26 drives a motor driver/MOSFET gate, never the motor directly.
   Serial output is newline JSON at 115200 baud. Input R/F/B/0 selects alerts.
*/
#include <Arduino.h>

constexpr int HALL_PIN = 27;
constexpr int VIBRATION_DRIVER_PIN = 26;
constexpr float WHEEL_CIRCUMFERENCE_M = 0.68f;  // Replace with measured value.
constexpr unsigned PULSES_PER_REV = 1;

portMUX_TYPE pulseMux = portMUX_INITIALIZER_UNLOCKED;
volatile uint32_t pulseCount = 0;
volatile uint32_t lastPulseUs = 0;
volatile uint32_t periodUs = 0;
char alert = '0';
uint32_t lastCommandMs = 0;
uint32_t lastReportMs = 0;

void IRAM_ATTR onWheelPulse() {
  const uint32_t now = micros();
  portENTER_CRITICAL_ISR(&pulseMux);
  const uint32_t interval = now - lastPulseUs;
  if (pulseCount == 0 || interval >= 2000) {
    if (pulseCount > 0) periodUs = interval;
    lastPulseUs = now;
    pulseCount++;
  }
  portEXIT_CRITICAL_ISR(&pulseMux);
}

void setup() {
  Serial.begin(115200);
  pinMode(HALL_PIN, INPUT_PULLUP);
  pinMode(VIBRATION_DRIVER_PIN, OUTPUT);
  digitalWrite(VIBRATION_DRIVER_PIN, LOW);
  attachInterrupt(digitalPinToInterrupt(HALL_PIN), onWheelPulse, FALLING);
}

void loop() {
  const uint32_t nowMs = millis();
  while (Serial.available()) {
    const char command = Serial.read();
    if (command == 'R' || command == 'F' || command == 'B' || command == '0') {
      alert = command;
      lastCommandMs = nowMs;
    }
  }
  if (nowMs - lastCommandMs > 1000) alert = '0';
  const uint32_t phase = nowMs % 1000;
  const bool rearPulse = phase < 120 || (phase >= 240 && phase < 360);
  const bool frontPulse = phase < 500;
  const bool active = alert == 'B' || (alert == 'R' && rearPulse) ||
                      (alert == 'F' && frontPulse);
  digitalWrite(VIBRATION_DRIVER_PIN, active ? HIGH : LOW);

  if (nowMs - lastReportMs >= 100) {
    lastReportMs = nowMs;
    portENTER_CRITICAL(&pulseMux);
    const uint32_t count = pulseCount;
    const uint32_t last = lastPulseUs;
    const uint32_t period = periodUs;
    portEXIT_CRITICAL(&pulseMux);
    Serial.print("{\"speed_mps\":");
    if (count < 2 || period == 0) {
      Serial.print("null");  // No speed measurement until two wheel pulses.
    } else {
      const uint32_t age = micros() - last;
      const uint32_t stopTimeout = max(uint32_t(1000000),
                                       uint32_t(min(uint64_t(period) * 2, uint64_t(5000000))));
      const float speed = age > stopTimeout ? 0.f :
                          WHEEL_CIRCUMFERENCE_M * 1000000.f / (period * PULSES_PER_REV);
      Serial.print(speed, 3);
    }
    Serial.print(",\"ticks\":");
    Serial.print(count);
    Serial.println("}");
  }
  delay(2);
}
