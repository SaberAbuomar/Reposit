"""Local driving dashboard with a measured rear scene."""
import argparse
from io import BytesIO
import threading
import time
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import app as engine
from motion import add_motion_arguments, validate_motion_arguments
from driving_view import render_scene
from speaker_alerts import SpokenWarnings, warning_phrase
BG, PANEL, FG, MUTED, BLUE = '#0b1018', '#141d29', '#edf3fc', '#8b9ab0', '#64b5ff'

class Dashboard:
    def __init__(self, root, args):
        self.root, self.args = root, args
        self.started, self.last_beep = False, 0
        self.sound = tk.BooleanVar(value=True)
        self.speech = SpokenWarnings()
        self.mode = tk.StringVar(value=args.mode)
        self.stationary = tk.BooleanVar(value=getattr(args, 'stationary_rig', False))
        self.stationary.trace_add('write', lambda *_: setattr(self.args, 'stationary_rig', self.stationary.get()))
        self.preview = tk.StringVar(value='Camera')
        self.gyro_axis = tk.StringVar(value=args.gyro_axis + ('+' if args.gyro_sign > 0 else '-'))
        root.title('Scooter Guard | Live Surroundings')
        root.geometry('1320x880')
        root.minsize(980, 700)
        root.configure(bg=BG)
        if root.tk.call('tk', 'windowingsystem') == 'win32': root.state('zoomed')
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Treeview', background=PANEL, foreground=FG, fieldbackground=PANEL, rowheight=29, borderwidth=0)
        style.configure('Treeview.Heading', background='#202d3e', foreground=MUTED, relief='flat')
        header = tk.Frame(root, bg=BG)
        header.pack(fill='x', padx=24, pady=(18,12))
        self.label(header, 'SCOOTER GUARD', 22, FG, True).pack(side='left')
        self.source = self.label(header, 'READY', 10, BLUE, True)
        self.source.pack(side='left', padx=20)
        self.selector = ttk.Combobox(header, textvariable=self.mode, values=['oak','demo','webcam'], width=9, state='readonly')
        self.selector.pack(side='right', padx=8)
        self.start_button = tk.Button(header, text='Start sensing', command=self.start, bg=BLUE, fg=BG, relief='flat', padx=16, pady=7)
        self.start_button.pack(side='right')
        if args.mode == 'demo':
            tk.Button(header,text='Turn demo',command=self.turn_demo,bg='#34465b',fg=FG,relief='flat',padx=10,pady=7).pack(side='right',padx=8)
        tk.Checkbutton(header, text='Spoken alerts', variable=self.sound, bg=BG, fg=MUTED, selectcolor=PANEL, activebackground=BG).pack(side='right', padx=10)
        self.banner = tk.Label(root, text='READY TO CONNECT', bg='#182b3d', fg=FG, anchor='w', padx=20, pady=12, font=('Segoe UI',15,'bold'))
        self.banner.pack(fill='x', padx=24, pady=(0,12))
        metrics = tk.Frame(root, bg=BG)
        metrics.pack(fill='x', padx=24, pady=(0,12))
        self.metrics = {}
        for i,(key,title) in enumerate([('distance','FOCUSED OBJECT'),('closing','CLOSING SPEED'),('ttc','PREDICTED OVERLAP'),('score','RISK SCORE')]):
            card = tk.Frame(metrics, bg=PANEL, padx=16, pady=10)
            card.grid(row=0,column=i,sticky='nsew',padx=(0 if i==0 else 8,0))
            metrics.columnconfigure(i,weight=1,uniform='metric')
            self.label(card,title,9,MUTED,True).pack(anchor='w')
            value = self.label(card,'--',25,FG,True)
            value.pack(anchor='w')
            hint = self.label(card,'Waiting for measurements',9,MUTED)
            hint.pack(anchor='w')
            self.metrics[key] = (value,hint)
        body = tk.Frame(root,bg=BG)
        body.pack(fill='both',expand=True,padx=24)
        body.columnconfigure(0,weight=3,uniform='body')
        body.columnconfigure(1,weight=2,uniform='body')
        body.rowconfigure(0,weight=1)
        self.map = tk.Canvas(body,bg=PANEL,highlightthickness=0)
        self.map.grid(row=0,column=0,sticky='nsew',padx=(0,12))
        right = tk.Frame(body,bg=PANEL,padx=14,pady=12)
        right.grid(row=0,column=1,sticky='nsew')
        tabs = tk.Frame(right,bg=PANEL)
        tabs.pack(fill='x')
        self.label(tabs,'SENSOR VIEW',10,FG,True).pack(side='left')
        for name in ('Both','Depth','Camera'):
            tk.Radiobutton(tabs,text=name,variable=self.preview,value=name,indicatoron=False,bg='#202d3e',fg=MUTED,selectcolor='#365678',activebackground='#365678',activeforeground=FG,relief='flat',padx=7,pady=5).pack(side='right',padx=2)
        self.video = tk.Label(right,bg='#090e15',text='Camera feed appears here',fg=MUTED)
        self.video.pack(fill='both',expand=True,pady=10)
        self.sensor_hint = self.label(right,'Center depth --',11,FG)
        self.sensor_hint.pack(anchor='w')
        self.calibration_hint = self.label(right,'Depth and color are synchronized',9,MUTED)
        self.calibration_hint.pack(anchor='w',pady=(4,8))
        self.motion_status = tk.Label(right,bg=PANEL,fg=MUTED,font=('Segoe UI',9),anchor='w',justify='left')
        self.motion_status.pack(fill='x')
        self.intent_status = tk.Label(right,bg=PANEL,fg='#ffca79',font=('Segoe UI',9),anchor='w',justify='left',wraplength=420)
        self.intent_status.pack(fill='x',pady=(6,0))
        tk.Checkbutton(right,text='Stationary rig (scooter must stay still)',variable=self.stationary,bg=PANEL,fg=MUTED,selectcolor=BG,activebackground=PANEL).pack(anchor='w')
        controls = tk.Frame(right,bg=PANEL)
        controls.pack(fill='x',pady=(8,0))
        tk.Button(controls,text='Calibrate yaw - hold still',command=engine.motion_inputs.calibrate,bg='#233247',fg=FG,relief='flat',padx=8,pady=5).pack(side='left')
        axes = ttk.Combobox(controls,textvariable=self.gyro_axis,values=['x+','x-','y+','y-','z+','z-'],width=4,state='readonly')
        axes.pack(side='left',padx=6)
        axes.bind('<<ComboboxSelected>>',self.change_axis)
        self.health = self.label(root,'Waiting for sensor',9,MUTED)
        self.health.pack(fill='x',padx=24,pady=(8,5))
        self.table = ttk.Treeview(root,columns=('object','distance','closing','ttc','risk','quality'),show='headings',height=3)
        for key,title,width in [('object','TRACKED OBJECT',150),('distance','DISTANCE',110),('closing','CLOSING SPEED',120),('ttc','OVERLAP IN',110),('risk','RISK SCORE',110),('quality','MEASUREMENT STATUS',280)]:
            self.table.heading(key,text=title)
            self.table.column(key,width=width,anchor='w')
        self.table.tag_configure('alert',foreground='#ff858b')
        self.table.pack(fill='x',padx=24)
        self.label(root,'EXPERIMENTAL PROTOTYPE  |  Risk score is not a crash probability  |  Visible rear sector only',9,MUTED).pack(pady=9)
        root.protocol('WM_DELETE_WINDOW',self.close)
        self.update()
        if args.autostart: root.after(100,self.start)

    @staticmethod
    def label(parent,text,size,color,bold=False):
        return tk.Label(parent,text=text,bg=parent.cget('bg'),fg=color,font=('Segoe UI',size,'bold' if bold else 'normal'),anchor='w')

    @staticmethod
    def measure(value,unit):
        return '--' if value is None else f'{value:.1f} {unit}'

    def start(self):
        if self.started: return
        self.started = True
        self.args.mode = self.mode.get()
        self.start_button.configure(state='disabled',text='Sensing active')
        self.selector.configure(state='disabled')
        with engine.lock: engine.state.update(mode=self.args.mode,status='Starting capture',error=None)
        engine.start_inputs(self.args)
        threading.Thread(target=engine.detect_loop,args=(self.args,),daemon=True).start()

    def turn_demo(self):
        if self.mode.get() == 'demo':
            with engine.lock:
                engine.state['demo_override'] = (3, time.monotonic())

    def change_axis(self,event=None):
        value = self.gyro_axis.get()
        self.args.gyro_axis,self.args.gyro_sign = value[0],1 if value[1]=='+' else -1
        engine.motion_inputs.configure(self.args.gyro_axis,self.args.gyro_sign)

    def update(self):
        s = engine.status()
        objects,motion = s['objects'],s.get('motion',{})
        stale = s['stale'] or bool(s.get('error'))
        if stale: objects=[]
        with engine.lock: image,depth = engine.jpeg,engine.depth_jpeg
        selection = self.preview.get()
        if image and not stale:
            frame = Image.open(BytesIO(depth if selection=='Depth' and depth else image)).convert('RGB')
            if selection=='Both' and depth:
                d=Image.open(BytesIO(depth)).convert('RGB')
                combined=Image.new('RGB',(frame.width,frame.height+d.height),'#090e15')
                combined.paste(frame,(0,0))
                combined.paste(d,(0,frame.height))
                frame=combined
            frame.thumbnail((max(100,self.video.winfo_width()),max(80,self.video.winfo_height())))
            self.photo=ImageTk.PhotoImage(frame)
            self.video.configure(image=self.photo,text='')
        elif stale: self.video.configure(image='',text='Waiting for fresh sensor frames')
        measured=[o for o in objects if o.get('distance') is not None]
        focus=max(measured,key=lambda o:(bool(o.get('alert')),o.get('score') or 0,-o['distance']),default=None)
        alert=any(o.get('alert') for o in objects) or bool(s.get('front') and s['front']['alert'])
        ready=bool(focus and focus.get('motion_ready'))
        extrapolated=bool(focus and focus.get('coasting'))
        values={'distance':(('~' if focus and focus.get('coasting') else '')+self.measure(focus['distance'] if focus else None,'m'),f"{focus['label'].title()} #{focus['id']}" if focus else 'No depth-qualified object'),
                'closing':(self.measure(focus.get('closing') if ready else None,'m/s'),'Positive = approaching'),
                'ttc':(self.measure(focus.get('ttc') if ready else None,'s'),'Projected footprint overlap'),
                'score':(f"{focus['score']} / 100" if ready else '--','Unobserved projection' if extrapolated else 'Experimental threat estimate')}
        for key,(value,hint) in values.items():
            self.metrics[key][0].configure(text=value,fg='#ff858b' if alert else FG)
            self.metrics[key][1].configure(text=hint)
        mode=s.get('mode')
        self.source.configure(text={'oak':'LIVE OAK-D LITE','demo':'SIMULATION','webcam':'WEBCAM / NO DEPTH'}.get(mode,'READY'),fg='#ffca79' if mode=='demo' else BLUE)
        message,color='MONITORING REAR SURROUNDINGS','#182b3d'
        if not self.started: message='READY / START SENSING'
        elif s.get('error'):
            message,color='SENSOR ERROR / '+str(s['error']),'#48242d'
            self.started=False
            self.start_button.configure(state='normal',text='Retry')
            self.selector.configure(state='readonly')
        elif stale: message='CONNECTING / WAITING FOR FRESH SENSOR DATA'
        elif alert:
            message,color='APPROACH WARNING / PREDICTED PATH CONFLICT','#622b36'
            if self.sound.get() and time.monotonic()-self.last_beep>1.1:
                self.root.bell()
                self.last_beep=time.monotonic()
        elif any(o.get('possible_turn_conflict') for o in objects):
            message,color='CAUTION / POSSIBLE TURN CONFLICT - ASSUMED PATHS','#554024'
        elif mode=='demo': message='SIMULATION / SYNTHETIC SCENARIO'
        elif mode=='webcam': message='CAMERA PREVIEW / DISTANCE UNAVAILABLE'
        elif focus and not ready: message='OBJECT DETECTED / ESTIMATING MOTION'
        self.speech.update(warning_phrase(objects, s.get('front'), stale=stale or not self.started, error=bool(s.get('error'))), self.sound.get())
        self.banner.configure(text=message,bg=color,wraplength=max(800,self.root.winfo_width()-100))
        self.sensor_hint.configure(text='Center depth  '+self.measure(None if stale else s.get('center_distance'),'m')+('  |  warm = near / cool = far' if selection!='Camera' else ''))
        cal=s.get('depth_calibration',{})
        self.calibration_hint.configure(text=('Provisional correction | raw '+self.measure(None if stale else s.get('center_raw_distance'),'m')+(' | extrapolated' if cal.get('extrapolated') else '')) if cal.get('provisional') else 'Factory depth | center sampling region')
        self.motion_status.configure(text='Scooter speed '+self.measure(motion.get('speed_mps'),'m/s')+' | IMU '+str(motion.get('imu',s.get('imu_detected','--')))+'\n'+motion.get('quality','Relative motion only')+'\n'+motion.get('imu_status',''))
        intent_focus=next((o for o in objects if o.get('possible_turn_conflict')),focus)
        intent_text='Signal: unknown | Turn start cannot be measured from a blinker'
        if intent_focus:
            signal=intent_focus.get('signal',{})
            intent_text='Signal: '+signal.get('state','unknown')+'\n'+intent_focus.get('turn_status','No supported turning intent')
            if intent_focus.get('view_orientation')=='side-view estimate': intent_text+='\nSide view estimated / exact heading unknown'
            window=intent_focus.get('turn_window')
            if window: intent_text+=f'\nPossible conflict in {window[0]:.1f}-{window[1]:.1f} s under assumptions'
            if intent_focus.get('coasting'): intent_text+=f"\nLAST SEEN {intent_focus['last_seen_age_s']:.1f} s ago / uncertainty +/-{intent_focus['position_uncertainty_m']:.1f} m"
        self.intent_status.configure(text=intent_text)
        missing=sum(o.get('distance') is None for o in objects)
        self.health.configure(text=f"{len(objects)} tracked | {missing} without depth | {s.get('fps',0)} processing FPS | "+s['status']+(' | '+self.speech.error if self.speech.error else ''))
        self.table.delete(*self.table.get_children())
        for o in objects:
            self.table.insert('','end',tags=('alert',) if o.get('alert') else (),values=(f"{o['label'].title()} #{o['id']}"+(' [last seen]' if o.get('coasting') else ''),self.measure(o.get('distance'),'m'),self.measure(o.get('closing'),'m/s'),self.measure(o.get('ttc'),'s'),f"{o['score']} / 100" if o.get('motion_ready') else '--','No valid depth' if o.get('distance') is None else o.get('reason','Collecting samples')))
        render_scene(self.map,objects,stale=stale,simulated=mode=='demo')
        self.root.after(120,self.update)

    def close(self):
        engine.stop.set()
        self.root.destroy()

if __name__ == '__main__':
    import sys
    if sys.platform == 'win32':
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['demo', 'oak', 'webcam'], default='demo')
    parser.add_argument('--camera', type=int, default=0)
    parser.add_argument('--usb2', action='store_true', help='Use USB 2 compatibility mode')
    parser.add_argument('--lidar-port')
    parser.add_argument('--lidar-baud', type=int, default=115200)
    parser.add_argument('--front-threshold', type=float, default=1.5)
    parser.add_argument('--autostart', action='store_true')
    add_motion_arguments(parser)
    args = parser.parse_args()
    validate_motion_arguments(parser, args)
    root = tk.Tk()
    Dashboard(root, args)
    root.mainloop()
