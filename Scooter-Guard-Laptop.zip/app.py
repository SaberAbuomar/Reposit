import argparse
from collections import deque
from datetime import timedelta
import logging
from io import BytesIO
from pathlib import Path
import threading
import time

import numpy as np
from PIL import Image, ImageDraw
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, StreamingResponse

from risk import MotionTracker, parse_tf_frame
from tracking import BoxTracker
from intent import IntentTracker
from motion import MotionInputs, add_motion_arguments, validate_motion_arguments, telemetry_loop
from depth_measurement import DepthCalibration

ROOT = Path(__file__).resolve().parent
logging.basicConfig(filename=ROOT / 'camera.log', level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')
app = FastAPI()
lock = threading.Lock()
state = dict(mode='starting', status='Starting', objects=[], front=None,
             fps=0, error=None, updated=0, lidar_status='Disabled')
jpeg = None
depth_jpeg = None
stop = threading.Event()
motion_inputs = MotionInputs()
inputs_started = False
depth_calibration = DepthCalibration()
calibration_mtime = None
calibration_checked_at = 0.


def refresh_depth_calibration(tracker):
    global depth_calibration, calibration_mtime, calibration_checked_at
    now = time.monotonic()
    if now - calibration_checked_at < 1:
        return
    calibration_checked_at = now
    path = ROOT / 'depth_calibration.json'
    mtime = path.stat().st_mtime_ns if path.exists() else None
    if mtime == calibration_mtime:
        return
    calibration_mtime = mtime
    try:
        candidate = DepthCalibration.load(path)
        depth_calibration = candidate
        tracker.history.clear()
        tracker.alert_since.clear()
        if hasattr(tracker, 'intent'): tracker.intent = IntentTracker(tracker.config)
        logging.info('Reloaded depth correction: %s, %s references', candidate.method, candidate.count)
    except (ValueError, KeyError, TypeError, OSError) as exc:
        logging.error('Depth correction reload rejected; previous correction retained: %s', exc)


def start_inputs(args):
    global inputs_started
    if inputs_started:
        return
    inputs_started = True
    motion_inputs.configure(args.gyro_axis, args.gyro_sign)
    if args.motion_port or args.motion_file:
        threading.Thread(target=telemetry_loop,
                         args=(args, motion_inputs, stop, current_alerts), daemon=True).start()
    if args.lidar_port:
        threading.Thread(target=lidar_loop, args=(args,), daemon=True).start()


def current_alerts():
    snapshot = status()
    return (any(obj['alert'] for obj in snapshot['objects']),
            bool(snapshot['front'] and snapshot['front']['alert']))


def publish(frame, objects, mode, fps, status='Running', depth_frame=None, center_distance=None):
    global jpeg, depth_jpeg
    encoded = BytesIO()
    Image.fromarray(frame[:, :, ::-1]).save(encoded, format='JPEG', quality=82)
    encoded_depth = None
    if depth_frame is not None:
        encoded_depth = BytesIO()
        Image.fromarray(depth_frame[:, :, ::-1]).save(encoded_depth, format='JPEG', quality=85)
    with lock:
        jpeg = encoded.getvalue()
        depth_jpeg = encoded_depth.getvalue() if encoded_depth else None
        state.update(objects=objects, mode=mode, fps=round(fps, 1),
                     status=status, updated=time.monotonic(), error=None,
                     center_distance=center_distance)


def oak_pipeline(imu_enabled=False):
    import depthai as dai
    pipeline = dai.Pipeline()
    rgb = pipeline.create(dai.node.ColorCamera)
    rgb.setBoardSocket(dai.CameraBoardSocket.CAM_A)
    rgb.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
    rgb.setIspScale(1, 3)
    rgb.setFps(15)
    left = pipeline.create(dai.node.MonoCamera)
    right = pipeline.create(dai.node.MonoCamera)
    for camera, socket in [(left, dai.CameraBoardSocket.CAM_B),
                           (right, dai.CameraBoardSocket.CAM_C)]:
        camera.setBoardSocket(socket)
        camera.setResolution(dai.MonoCameraProperties.SensorResolution.THE_400_P)
        camera.setFps(15)
    stereo = pipeline.create(dai.node.StereoDepth)
    stereo.setDefaultProfilePreset(dai.node.StereoDepth.PresetMode.HIGH_ACCURACY)
    stereo.setLeftRightCheck(True)
    stereo.setSubpixel(True)
    stereo.setDepthAlign(dai.CameraBoardSocket.CAM_A)
    stereo.setOutputSize(640, 360)
    left.out.link(stereo.left)
    right.out.link(stereo.right)
    sync = pipeline.create(dai.node.Sync)
    sync.setSyncThreshold(timedelta(milliseconds=35))
    sync.setSyncAttempts(-1)
    rgb.isp.link(sync.inputs['rgb'])
    stereo.depth.link(sync.inputs['depth'])
    output = pipeline.create(dai.node.XLinkOut)
    output.setStreamName('frames')
    sync.out.link(output.input)
    if imu_enabled:
        imu = pipeline.create(dai.node.IMU)
        imu.enableIMUSensor(dai.IMUSensor.GYROSCOPE_RAW, 100)
        imu.setBatchReportThreshold(1)
        imu.setMaxBatchReports(10)
        imu_output = pipeline.create(dai.node.XLinkOut)
        imu_output.setStreamName('imu')
        imu.out.link(imu_output.input)
    return pipeline


def capture_oak(args, model):
    import depthai as dai
    attempts = 0
    while not stop.is_set():
        try:
            with lock:
                state.update(status='Connecting to OAK-D Lite over USB', error=None, objects=[])
            speed = dai.UsbSpeed.HIGH if getattr(args, 'usb2', False) else dai.UsbSpeed.SUPER
            with dai.Device(dai.OpenVINO.Version.VERSION_UNIVERSAL, speed) as device:
                imu_name = device.getConnectedIMU()
                imu_enabled = bool(imu_name and imu_name.upper() not in ('NONE', 'UNKNOWN'))
                motion_inputs.set_imu(imu_name if imu_enabled else '')
                logging.info('OAK connected: USB=%s IMU=%s', device.getUsbSpeed(), imu_name)
                with lock:
                    state['imu_detected'] = imu_name or 'Absent'
                device.startPipeline(oak_pipeline(imu_enabled))
                calibration = device.readCalibration()
                intrinsics = calibration.getCameraIntrinsics(dai.CameraBoardSocket.CAM_A, 640, 360)
                queue = device.getOutputQueue('frames', maxSize=1, blocking=False)
                imu_queue = device.getOutputQueue('imu', maxSize=50, blocking=False) if imu_enabled else None
                tracker = MotionTracker(vars(args))
                tracker.boxes = BoxTracker()
                last_frame = time.monotonic()
                attempts = 0
                while not stop.is_set():
                    if imu_queue:
                        for batch in imu_queue.tryGetAll():
                            for packet in batch.packets:
                                gyro = packet.gyroscope
                                age = max(0., (dai.Clock.now() - gyro.getTimestamp()).total_seconds())
                                motion_inputs.ingest_gyro(time.monotonic() - age, [gyro.x, gyro.y, gyro.z])
                    group = queue.tryGet()
                    if group is None:
                        if time.monotonic() - last_frame > 5:
                            raise RuntimeError('OAK frame stream timed out')
                        stop.wait(.005)
                        continue
                    last_frame = time.monotonic()
                    age = max(0., (dai.Clock.now() - group['rgb'].getTimestamp()).total_seconds())
                    timestamp = time.monotonic() - age
                    ego = motion_inputs.advance(timestamp, args.reaction_time, args.deceleration)
                    refresh_depth_calibration(tracker)
                    process_frame(model, tracker, group['rgb'].getCvFrame(), group['depth'].getFrame(),
                                  intrinsics, timestamp, 'oak', ego)
        except RuntimeError as exc:
            if stop.is_set():
                return
            attempts += 1
            logging.exception('OAK stream reconnect attempt %s', attempts)
            with lock:
                state.update(status=f'Reconnecting camera · attempt {attempts}',
                             connection_detail=str(exc), objects=[], updated=0, error=None)
            stop.wait(min(8., 2. + attempts))


def detect_loop(args):
    global depth_calibration, calibration_mtime
    try:
        if args.mode == 'demo':
            demo_loop()
            return
        import cv2
        depth_calibration = DepthCalibration.load(ROOT / 'depth_calibration.json')
        profile_path = ROOT / 'depth_calibration.json'
        calibration_mtime = profile_path.stat().st_mtime_ns if profile_path.exists() else None
        logging.info('Depth correction %s from %s user references',
                     depth_calibration.method, depth_calibration.count)
        from ultralytics import YOLO
        with lock:
            state['status'] = 'Loading detector (first start may download weights)'
        weights = next((ROOT / name for name in ('yolo11n.pt', 'yolov8n.pt')
                        if (ROOT / name).is_file()), None)
        if weights is None:
            raise RuntimeError('Detector weights are missing. Place yolo11n.pt or yolov8n.pt in the project folder.')
        model = YOLO(str(weights))
        tracker = MotionTracker(vars(args))
        tracker.boxes = BoxTracker()
        if args.mode == 'oak':
            capture_oak(args, model)
        else:
            capture = cv2.VideoCapture(args.camera)
            if not capture.isOpened():
                raise RuntimeError('Laptop camera could not be opened.')
            try:
                while not stop.is_set():
                    ok, frame = capture.read()
                    if not ok:
                        raise RuntimeError('Laptop camera stream stopped.')
                    process_frame(model, tracker, frame, None, None,
                                  time.monotonic(), 'webcam')
            finally:
                capture.release()
    except Exception as exc:
        logging.exception('Capture stopped')
        with lock:
            state.update(status='Stopped', error=str(exc), objects=[])


def process_frame(model, tracker, frame, depth, intrinsics, timestamp, mode, ego=None):
    import cv2
    started = time.monotonic()
    lamp_frame = frame.copy()
    result = model.predict(frame,
                         classes=[0, 1, 2, 3, 5, 7], conf=0.45,
                         imgsz=416, device='cpu', verbose=False)[0]
    objects = []
    ego = ego or motion_inputs.advance(timestamp)
    with lock:
        state['motion'] = ego
    depth_view = None
    center_distance = None
    with lock:
        state['center_raw_distance'] = None
        state['depth_calibration'] = depth_calibration.describe()
    if depth is not None:
        raw_depth = depth
        depth = depth_calibration.correct(depth.astype(np.float32) / 1000) * 1000
        # Fixed 0.5-12 m scale keeps colors consistent from frame to frame.
        valid_depth = (depth >= 500) & (depth <= 12000)
        scaled = np.clip((12000 - depth.astype(np.float32)) / 11500 * 255, 0, 255).astype(np.uint8)
        depth_view = cv2.applyColorMap(scaled, cv2.COLORMAP_TURBO)
        depth_view[~valid_depth] = 0
        height, width = depth.shape
        cx, cy = width // 2, height // 2
        center = depth[cy - 12:cy + 12, cx - 12:cx + 12]
        center_valid = center[(center >= 500) & (center <= 12000)]
        raw_center_distance = None
        if center_valid.size >= center.size * .2:
            raw_center = raw_depth[cy - 12:cy + 12, cx - 12:cx + 12]
            raw_center_distance = float(np.median(raw_center[(center >= 500) & (center <= 12000)])) / 1000
            center_distance = depth_calibration.correct(raw_center_distance)
        with lock:
            state['center_raw_distance'] = raw_center_distance
            state['depth_calibration'] = depth_calibration.describe(raw_center_distance)
        cv2.rectangle(depth_view, (cx - 12, cy - 12), (cx + 12, cy + 12), (255, 255, 255), 1)
        cv2.rectangle(frame, (cx - 12, cy - 12), (cx + 12, cy + 12), (255, 255, 255), 1)
        center_text = f'Center: {center_distance:.2f} m' if center_distance is not None else 'Center: no valid depth'
        cv2.putText(depth_view, center_text, (14, height - 18),
                    cv2.FONT_HERSHEY_SIMPLEX, .65, (255, 255, 255), 2, cv2.LINE_AA)
    boxes = result.boxes.xyxy.cpu().numpy()
    classes = result.boxes.cls.cpu().numpy().astype(int)
    ids = tracker.boxes.update(boxes, classes, timestamp)
    for box, track_id in zip(result.boxes, ids):
        label = model.names[int(box.cls.item())]
        x1, y1, x2, y2 = box.xyxy[0].cpu().numpy().astype(int)
        item = dict(id=track_id, label=label, confidence=round(float(box.conf.item()), 2),
                    distance=None, x=None, score=None, alert=False, ttc=None,
                    closing=None, motion_ready=False)
        if depth is not None:
            height, width = depth.shape
            # Central torso/body ROI avoids much of the surrounding background.
            xa = max(0, min(width, int(x1 + (x2 - x1) * .3)))
            xb = max(0, min(width, int(x1 + (x2 - x1) * .7)))
            ya = max(0, min(height, int(y1 + (y2 - y1) * .3)))
            yb = max(0, min(height, int(y1 + (y2 - y1) * .7)))
            roi = depth[ya:yb, xa:xb]
            valid = roi[(roi >= 500) & (roi <= 12000)]
            if roi.size and valid.size >= max(12, roi.size * .2):
                raw_roi = raw_depth[ya:yb, xa:xb]
                raw_z = float(np.median(raw_roi[(roi >= 500) & (roi <= 12000)])) / 1000
                z = depth_calibration.correct(raw_z)
                fx, cx = intrinsics[0][0], intrinsics[0][2]
                x = ((x1 + x2) / 2 - cx) * z / fx
                object_width = max(.4, min(3, (x2 - x1) * z / fx))
                item.update(tracker.update(track_id, timestamp, x, z, object_width,
                                           label=label, ego=ego, confidence=item['confidence']))
                item['distance_raw'] = round(raw_z, 3)
                item['calibration_provisional'] = depth_calibration.count > 0
        color = (75, 75, 245) if item['alert'] else (180, 220, 70)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        text = f'{label} #{track_id}'
        if item['distance'] is not None:
            text += f" {item['distance']:.2f}m | {item['score']}/100"
            if item.get('ttc') is not None:
                text += f" | overlap {item['ttc']:.1f}s"
        else:
            text += ' | distance unavailable'
        cv2.putText(frame, text, (max(0, x1), max(20, y1 - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX, .5, color, 1, cv2.LINE_AA)
        if depth_view is not None:
            cv2.rectangle(depth_view, (x1, y1), (x2, y2), color, 2)
            cv2.putText(depth_view, text, (max(0, x1), max(20, y1 - 8)),
                        cv2.FONT_HERSHEY_SIMPLEX, .5, (255, 255, 255), 1, cv2.LINE_AA)
        objects.append(item)
    if not hasattr(tracker, 'intent'):
        tracker.intent = IntentTracker(tracker.config)
    boxes_by_id = {track_id: box for track_id, box in zip(ids, boxes)}
    objects = tracker.intent.update(objects, lamp_frame, boxes_by_id, timestamp, ego)
    tracker.prune(timestamp)
    publish(frame, objects, mode, 1 / max(.001, time.monotonic() - started),
            depth_frame=depth_view, center_distance=center_distance)


def demo_loop():
    tracker = MotionTracker()
    start = time.monotonic()
    previous_scenario = None
    previous_phase = -1.
    demo_intent = IntentTracker({'stationary_rig': True})
    while not stop.wait(.08):
        now = time.monotonic()
        scenario = int((now - start) // 12) % 4
        phase = (now - start) % 12
        with lock:
            override = state.get('demo_override')
        if override:
            scenario = override[0]
            phase = (now - override[1]) % 12
        if scenario != previous_scenario or phase < previous_phase:
            tracker = MotionTracker()
            previous_scenario = scenario
            demo_intent = IntentTracker({'stationary_rig': True})
        previous_phase = phase
        title = ['Rear approach', 'Passing with lateral clearance', 'Pedestrian crossing', 'Amber blink / possible cut-in / brief lost view'][scenario]
        x, z, label = (0., max(.8, 12 - phase), 'car') if scenario == 0 else (
                      (4., max(.8, 12 - phase), 'car') if scenario == 1 else
                      ((4. - phase * .8, .7, 'person') if scenario == 2 else (3., max(.8, 7 - phase * 1.2), 'car')))
        image = Image.new('RGB', (640, 360), (16, 22, 28))
        draw = ImageDraw.Draw(image)
        size = int(240 / max(1, z))
        draw.rectangle((320 - size, 190 - size, 320 + size, 190 + size),
                       outline=(70, 220, 180), width=2)
        draw.text((30, 30), 'SIMULATED APPROACH - NO SENSOR DATA', fill=(255, 190, 80))
        draw.text((30, 50), title, fill=(255, 255, 255))
        if scenario == 3 and int(phase / .4) % 2 == 0:
            draw.rectangle((235, 190, 248, 204), fill=(255, 190, 0))
        frame = np.asarray(image)[:, :, ::-1].copy()
        item = dict(id=1, label='simulated ' + label, confidence=1,
                    **tracker.update(1, now, x, z, label=label))
        demo_objects = [item]
        if scenario == 3:
            demo_ego = dict(yaw=0., position=[0.,0.], generation=0, speed_mps=None, yaw_rate_rps=None, quality='SIMULATED stationary rig')
            # Simulate a brief missing detection, then a full expiry; never live lamp evidence.
            demo_objects = demo_intent.update([] if 4.5 < phase < 5.3 or phase > 8 else [item], frame, {1: [220,100,420,300]}, now, demo_ego)
        with lock:
            state['motion'] = dict(quality='SIMULATED relative motion', imu='Simulated',
                                   imu_status=title, speed_mps=None, yaw_rate_rps=None,
                                   stopping_distance=None, input_status='Synthetic measurements')
        publish(frame, demo_objects, 'demo', 12.5, 'Simulated data')


def lidar_loop(args):
    import serial
    samples = deque(maxlen=8)
    try:
        with serial.Serial(args.lidar_port, args.lidar_baud, timeout=.2) as port:
            with lock:
                state['lidar_status'] = f'Connected to {args.lidar_port}; waiting for valid packets'
            buffer = bytearray()
            while not stop.is_set():
                buffer.extend(port.read(max(1, port.in_waiting)))
                while len(buffer) >= 9:
                    if buffer[:2] != b'YY':
                        del buffer[0]
                        continue
                    packet = bytes(buffer[:9])
                    if sum(packet[:8]) & 255 != packet[8]:
                        del buffer[0]
                        continue
                    del buffer[:9]
                    distance = parse_tf_frame(packet)
                    if distance is None:
                        continue
                    now = time.monotonic()
                    if samples and now - samples[-1][0] > .5:
                        samples.clear()
                    samples.append((now, distance))
                    closing = None
                    if len(samples) >= 3 and now - samples[0][0] >= .1:
                        closing = (samples[0][1] - distance) / (now - samples[0][0])
                    ttc = distance / closing if closing and closing > .25 else None
                    with lock:
                        state['lidar_status'] = 'Receiving front distance'
                        state['front'] = dict(distance=round(distance, 2),
                                              closing=round(closing, 2) if closing is not None else None,
                                              alert=distance < args.front_threshold or
                                              (ttc is not None and ttc < 2),
                                              updated=now)
    except Exception as exc:
        with lock:
            state['lidar_status'] = f'LiDAR unavailable: {exc}'
            state['front'] = None


@app.get('/')
def index():
    return HTMLResponse((ROOT / 'templates' / 'index.html').read_text(encoding='utf-8'))


@app.get('/api/status')
def status():
    with lock:
        result = dict(state)
    now = time.monotonic()
    result['stale'] = now - result['updated'] > 2
    if result['stale']:
        result['objects'] = []
        result['motion'] = dict(result.get('motion', {}), speed_mps=None, yaw_rate_rps=None,
                                stopping_distance=None, quality='Camera measurements unavailable')
    if result['front'] and now - result['front']['updated'] > 1:
        result['front'] = None
        result['lidar_status'] = 'No recent valid LiDAR data'
    return result


@app.get('/video')
def video():
    def frames():
        while not stop.wait(.07):
            with lock:
                data = jpeg
            if data:
                yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + data + b'\r\n'
    return StreamingResponse(frames(), media_type='multipart/x-mixed-replace; boundary=frame')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['oak', 'webcam', 'demo'], default='oak')
    parser.add_argument('--camera', type=int, default=0)
    parser.add_argument('--usb2', action='store_true', help='Use USB 2 compatibility mode')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--lidar-port')
    parser.add_argument('--lidar-baud', type=int, default=115200)
    parser.add_argument('--front-threshold', type=float, default=1.5)
    add_motion_arguments(parser)
    args = parser.parse_args()
    validate_motion_arguments(parser, args)
    start_inputs(args)
    threading.Thread(target=detect_loop, args=(args,), daemon=True).start()
    try:
        import uvicorn
        uvicorn.run(app, host='127.0.0.1', port=args.port)
    finally:
        stop.set()
