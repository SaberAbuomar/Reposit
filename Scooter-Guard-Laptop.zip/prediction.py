"""Finite-footprint collision checks in a level, rear-facing camera frame."""
import math
import numpy as np
from motion import rotation, scooter_position

DIMENSIONS = {'person': (.6, .6), 'bicycle': (.7, 1.8), 'motorcycle': (.9, 2.2),
              'car': (1.8, 4.5), 'bus': (2.5, 10.), 'truck': (2.5, 8.)}


def footprint_gap(center_a, yaw_a, size_a, center_b, yaw_b, size_b):
    """SAT signed separation. <=0 means overlapping rectangles."""
    basis_a, basis_b = rotation(yaw_a), rotation(yaw_b)
    half_a, half_b = np.asarray(size_a) / 2, np.asarray(size_b) / 2
    delta = np.asarray(center_b) - center_a
    gaps = []
    for axis in (basis_a[:, 0], basis_a[:, 1], basis_b[:, 0], basis_b[:, 1]):
        radius_a = float(np.abs(axis @ basis_a) @ half_a)
        radius_b = float(np.abs(axis @ basis_b) @ half_b)
        gaps.append(abs(float(delta @ axis)) - radius_a - radius_b)
    return max(gaps)


def predict_collision(x, z, vx, vz, label, width, ego, config):
    horizon = config.get('horizon', 6.)
    margin = config.get('safety_margin', .3)
    scooter_size = (config.get('scooter_width', .6) + 2 * margin,
                    config.get('scooter_length', 1.2) + 2 * margin)
    nominal_width, length = DIMENSIONS.get(label, (1.8, 4.5))
    target_size = (max(nominal_width, width), length)
    # Stereo observes the visible surface. Offset the nominal center away from
    # the rear camera by half the object's assumed length.
    target_center = np.array([x, z + length / 2])
    relative_position = np.array([x, z])
    relative_velocity = np.array([vx, vz])
    speed = ego.get('speed_mps')
    yaw_rate = ego.get('yaw_rate_rps') or 0.
    # With speed input, fitted velocity is world-derived in the current camera
    # basis. Otherwise it is the rotation-compensated relative velocity.
    world_velocity = relative_velocity
    first_collision = None
    best_gap, best_time = math.inf, 0.
    path, ego_path = [], []
    for t in np.arange(0., horizon + .001, .1):
        scooter_center = scooter_position(speed, yaw_rate, t) if speed is not None else np.zeros(2)
        object_center = target_center + world_velocity * t
        gap = footprint_gap(scooter_center, yaw_rate * t, scooter_size,
                            object_center, 0., target_size)
        if gap < best_gap:
            best_gap, best_time = gap, float(t)
        if gap <= 0 and first_collision is None:
            first_collision = float(t)
        if round(t * 10) % 5 == 0:
            path.append((relative_position + relative_velocity * t).round(3).tolist())
            ego_path.append(scooter_center.round(3).tolist())
    score = 0
    if first_collision is not None:
        score = round(100 * max(0., min(1., (horizon - first_collision) / max(.1, horizon - 1))))
    elif best_gap < 1. and best_time > .1:
        score = round(30 * (1 - max(0., best_gap)))
    return dict(ttc=round(first_collision, 2) if first_collision is not None else None,
                clearance=round(best_gap, 2), closest_time=round(best_time, 2),
                score=score, collision_predicted=first_collision is not None,
                path=path, scooter_path=ego_path,
                reason='Predicted footprint overlap' if first_collision is not None else 'Close pass' if score else 'No overlap predicted')
